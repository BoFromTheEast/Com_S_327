#include <iostream>

using namespace std;

class singleton {
public:
  static singleton *get_instance()
  {
    if (!instance) {
      instance = new singleton;
    }

    return instance;
  }
  
  void print() { cout << value << endl; }

private:
  int value;
  
  static singleton *instance;
  singleton() { value = 5; }
  ~singleton() {}
};

singleton *singleton::instance; // Required for any static data

int main(int argc, char *argv[])
{
  singleton *s;

  s = singleton::get_instance();
 
  s->print();
 
  singleton *t;

  t = singleton::get_instance();

  t->print();

  cout << s << " " << t << endl;

  singleton::get_instance()->print();

  cout << s << " " << t << " " << singleton::get_instance() << endl;

  return 0;
}
