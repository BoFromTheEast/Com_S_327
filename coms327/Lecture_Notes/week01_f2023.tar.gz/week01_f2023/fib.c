#include <stdio.h>
#include <stdlib.h>

/* Recurrence
  fib_0 = 0
  fib_1 = 1
  fib_n = fib_{n-1} + fib_{n-2}
*/
unsigned fib(unsigned n)
{
  if (n <= 1) {
    return n;
  }

  return fib(n - 1) + fib(n - 2);
}

int main(int argc, char *argv[])
{
  if (argc != 2 || argv[1][0] == '-') {
    fprintf(stderr, "Usage: %s <positive number>\n", argv[0]);

    return -1;
  }
  
  printf("%u\n", fib(atoi(argv[1])));
  
  return 0;
}
