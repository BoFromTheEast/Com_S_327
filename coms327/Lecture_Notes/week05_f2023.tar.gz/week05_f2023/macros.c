

/* Two kinds of macros: value-type, function-type. */

#define PI 3.1415926

#define add(x, y) (x + y)

#define min(x, y) (x < y ? x : y)

#define max(x, y) ({ \
  typeof (x) _x = x; \
  typeof (y) _y = y; \
  _x > _y ? _x : _y; \
})

PI;

add(PI, 10) * 2;

min(4, 7);
min(really_expensive_function(), function_with_side_effects())
  

