#include <stdio.h>

extern int (*myprintf)(const char *format, ...);

int main(int argc, char *argv[])
{
  myprintf("Hello %s\n", "World!");

  return 0;
}
