#include <stdio.h>

int (*sideload_printf)(const char *format, ...);

int main(int argc, char *argv[])
{
  printf("Hello World!\n");

  sideload_printf("Goodbye cruel world.\n");

  return 0;
}
