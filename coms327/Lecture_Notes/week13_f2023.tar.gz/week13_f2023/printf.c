#include <stdio.h>
#include <stdarg.h>
#include <dlfcn.h>
#include <stdlib.h>

int (*sideload_printf)(const char *format, ...);

__attribute__((constructor))
void init()
{
  void *handle;
  
  printf(__FUNCTION__);
  printf("\n");

  if (!(handle = dlopen("c", RTLD_LAZY))) {
    fprintf(stderr, "%s\n", dlerror());

    exit(1);
  }

  if (!(sideload_printf = dlsym(handle, "printf"))) {
    fprintf(stderr, "%s\n", dlerror());

    exit(1);
  }
}

__attribute__((destructor))
void destroy()
{
  printf(__FUNCTION__);
  printf("\n");
}

int printf(const char *format, ...)
{
  va_list ap;
  int rval;

  fputs("im in ur librarz, manipulting ur bites\n", stdout);
  
  va_start(ap, format);

  rval = vprintf(format, ap);
  
  va_end(ap);

  return rval;
}

int puts(const char *s)
{
  fputs("s: ", stdout);
  return fputs(s, stdout);
}

int printf327(const char *format, ...)
{
  va_list ap;
  int rval;

  fputs("im in ur librarz, manipulting ur bites\n", stdout);
  
  va_start(ap, format);

  rval = vprintf(format, ap);
  
  va_end(ap);

  return rval;
}
