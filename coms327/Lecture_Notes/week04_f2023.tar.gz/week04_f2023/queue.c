#include <stdlib.h>

#include "queue.h"

int queue_init(struct queue *q)
{
  q->front = NULL;
  q->back = NULL;
  q->size = 0;

  return 0;
}

int queue_destroy(struct queue *q)
{
  struct queue_node *n;

  for (n = q->front; n; n = q->front) {
    q->front = n->next;
    free(n);
  }

  /* These two lines are not necessary!  The queue logically doesn't exists! */
  q->back = NULL;
  q->size = 0;
  
  return 0;
}

int queue_insert(struct queue *q, int i)
{
  struct queue_node *n;

  if (!(n = malloc(sizeof (struct queue_node)))) {
    return -1;
  }

  if (!q->front) {
    q->front = q->back = n;
  } else {
    q->back->next = n;
    q->back = n;
  }

  n->next = NULL;
  n->data = i;

  q->size++;

  return 0;
}

int queue_remove(struct queue *q, int *i)
{
  struct queue_node *n;
  
  if (!q->front) {
    return -1;
  }

  n = q->front;
  *i = n->data;
  if (!(q->front = n->next)) {
    q->back = NULL;
  }
  q->size--;
  q->front = n->next;

  free(n);
  
  return 0;
}

int queue_front(struct queue *q, int *i)
{
  if (!q->front) {
    return -1;
  }

  *i = q->front->data;

  return 0;
}

int queue_size(struct queue *q)
{
  return q->size;
}

int is_empty(struct queue *q)
{
  return !q->size;
}
