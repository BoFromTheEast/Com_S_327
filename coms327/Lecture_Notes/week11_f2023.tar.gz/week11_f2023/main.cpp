#include <iostream>
#include <string>

#include "darray.h"

using namespace std;

class foo {
};

int main(int argc, char *argv[])
{
  darray<int> ai;
  darray<string> as;
  int i;
  //  darray<foo> af;
  
  for (i = 0; i < 100; i++) {
    ai.add(i);
  }

  cout << ai << endl;

  ai.remove(42);
  
  cout << ai << endl;

  ai.set(10, 25);
  ai[5] = 50;
  ai.get(75) = 45;

  cout << ai << endl;

  as.add("Hello0");
  as.add("Hello1");
  as.add("Hello2");
  as.add("Hello3");
  as.add("Hello4");
  as.add("Hello5");
  as.add("Hello6");
  as.add("Hello7");
  as.add("Hello8");
  as.add("Hello9");

  cout << as << endl;

  //  cout << af << endl;
  
  try {
    for (i = 0;;i++) {
      ai[i] = i;

      cout << ai[i] << endl;
    }
  }

  catch (const char * s) {
    cout << s << endl;
  }
  catch (...) {  // Catches anything; must be last
    cout << "Caught an exception" << endl;
  }

  return 0;
}
