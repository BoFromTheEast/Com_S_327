#ifndef C_PART_H
#define C_PART_H

#ifdef __cplusplus
extern "C" {
#endif
  
void print_msg(const char *s);

#ifdef __cplusplus
}
#endif
  
#endif
