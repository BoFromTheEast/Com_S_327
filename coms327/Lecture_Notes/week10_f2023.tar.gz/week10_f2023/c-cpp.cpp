#include "c-part.h"

int main(int argc, char *argv[])
{
  print_msg("Hello World!\n");

  return 0;
}
