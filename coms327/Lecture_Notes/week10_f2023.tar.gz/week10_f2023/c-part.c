#include <stdio.h>

#include "c-part.h"

void print_msg(const char *s)
{
  printf("%s", s);
}
