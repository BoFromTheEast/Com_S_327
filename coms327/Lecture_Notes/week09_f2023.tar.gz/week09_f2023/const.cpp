#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
  volatile const int i = 0;

  cout << i << endl;

  *(int *) &i = 1;

  i = 2;

  return 0;
}
