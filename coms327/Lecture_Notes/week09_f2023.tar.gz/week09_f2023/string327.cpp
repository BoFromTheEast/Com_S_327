#include <cstring>

#include "string327.h"

string327::string327() {
  str = strdup("");
}


string327::string327(const char *s) {
  str = strdup(s);
}


string327::string327(const string327 &s) {
  str = strdup(s.str);
}


string327::~string327() {
  free(str);
}


int string327::length() const {
  return strlen(str);
}


bool string327::operator<(const string327 &rhs) const {
  return strcmp(str, rhs.str) < 0;
}


bool string327::operator>(const string327 &rhs) const {
  return strcmp(str, rhs.str) > 0;
}


bool string327::operator==(const string327 &rhs) const {
  return strcmp(str, rhs.str) == 0;
}


bool string327::operator!=(const string327 &rhs) const {
  return strcmp(str, rhs.str) != 0;
}


bool string327::operator<=(const string327 &rhs) const {
  return strcmp(str, rhs.str) <= 0;
}


bool string327::operator>=(const string327 &rhs) const {
  return strcmp(str, rhs.str) >= 0;
}


string327 string327::operator+(const string327 &rhs) const {
  string327 s;

  free(s.str);

  s.str = (char *) malloc(strlen(str) + strlen(rhs.str) + 1);

  strcpy(s.str, str);
  strcat(s.str, rhs.str);

  return s;
}


string327 string327::operator+(const char *rhs) const {
  string327 s;

  free(s.str);

  s.str = (char *) malloc(strlen(str) + strlen(rhs) + 1);

  strcpy(s.str, str);
  strcat(s.str, rhs);

  return s;
}


string327 &string327::operator+=(const string327 &rhs) {
  str = (char *) realloc(str, strlen(str) + strlen(rhs.str) + 1);

  strcat(str, rhs.str);

  return *this;
}

string327 &string327::operator+=(const char *rhs) {
  str = (char *) realloc(str, strlen(str) + strlen(rhs) + 1);

  strcat(str, rhs);

  return *this;
}


string327 &string327::operator=(const string327 &rhs) {
  free(str);

  str = strdup(rhs.str);

  return *this;
}

string327 &string327::operator=(const char *rhs) {
  free(str);

  str = strdup(rhs);

  return *this;
}


char &string327::operator[](const int i) const {
  return str[i];
}

const char *string327::c_str() const {
  return str;
}

std::istream &operator>>(std::istream &lhs, const string327 &rhs) {
  /* BUG!!!                                                                 */
  /* This completely ignores the fact that input may be too large for rhs!! */
  return lhs >> rhs.str;
}


std::ostream &operator<<(std::ostream &lhs, const string327 &rhs) {
  return lhs << rhs.c_str();
}
