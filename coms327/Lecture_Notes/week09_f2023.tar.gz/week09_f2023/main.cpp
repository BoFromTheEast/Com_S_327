#include "string327.h"

using namespace std;

int main(int argc, char *argv[])
{
  string327 s = "Hello ", t = "World!";

  if (s > t) {
    cout << "s is better!" << endl;
  } else {
    cout << "t is better!" << endl;
  }
  
  cout << s + t << endl;

  cout << s << endl << t << endl;

  s += t;

  cout << s << endl;

  s[6] = 'w';

  cout << s << endl;

  /*  
  cin >> s;

  cout << s << endl;
  */
  return 0;
}
