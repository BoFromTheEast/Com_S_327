#include <cmath>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

class shape {
public:
  virtual ~shape() {}
  virtual double perimeter() const = 0;
  virtual double area() const = 0;
  virtual ostream &print(ostream &o) const = 0;
};

ostream &operator<<(ostream &o, const shape &s)
{
  return s.print(o);
}

class rectangle : public shape {
protected:
  double length, width;
public:
  rectangle(double l, double w)
  {
    length = l;
    width = w;
  }

  virtual ~rectangle() {}
  
  virtual double perimeter() const
  {
    return 2 * (length + width);
  }

  virtual double area() const
  {
    return length * width;
  }

  virtual ostream &print(ostream &o) const
  {
    return o << "rectangle[length=" << length << ",width=" << width << "]";
  }
};

class square : public rectangle {
public:
  square(double s) : rectangle(s, s) {}

  ostream &print(ostream &o) const
  {
    return o << "square[side=" << length << "]";
  }
};

class circle : public shape {
private:
  double radius;
public:
  circle(double r)
  {
    radius = r;
  }

  double perimeter() const
  {
    return 2 * M_PI * radius;
  }

  double circumference() const
  {
    return 2 * M_PI * radius;
  }

  double area() const
  {
    return M_PI * radius * radius;
  }

  ostream &print(ostream &o) const
  {
    return o << "circle[radius=" << radius << "]";
  }  
};

int main(int argc, char *argv[])
{
  srand(time(NULL));
  
  shape *s = new square(4);

  cout << *s << ", perimeter=" << s->perimeter()
       << ", area=" << s->area() << endl;

  delete s;
  
  s = new circle(7);
  cout << *s << ", perimeter=" << s->perimeter()
       << ", area=" << s->area() << endl;
  cout << ((circle *) s)->circumference() << endl;

  rectangle r(4, 9);
  shape &sr = r;
  cout << sr << ", perimeter=" << sr.perimeter()
       << ", area=" << sr.area() << endl;

  vector<shape *> v;
  int i;
  for (i = 0; i < 100; i++) {
    switch (rand() % 3) {
    case 0:
      v.push_back(new circle(((double) RAND_MAX) / rand()));
      break;
    case 1:
      v.push_back(new rectangle(((double) RAND_MAX) / rand(),
                                ((double) RAND_MAX) / rand()));
      break;
    case 2:
      v.push_back(new square(((double) RAND_MAX) / rand()));
      break;
    }
  }

  /*
  for (i = 0; i < 100; i++) {
    cout << *v[i] << endl;
  }
  */

  vector<shape *>::iterator vi;

  for (vi = v.begin(); vi != v.end(); vi++) {
    cout << **vi << endl;
  }

  delete s;
  
  for (vi = v.begin(); vi != v.end(); vi++) {
    delete *vi;
  }

  vector<circle> vs;

  vs.push_back(circle(3));
  vs.push_back(circle(5));
  vs.push_back(circle(4));

  for (i = 0; i < vs.size(); i++) {
    cout << vs[i] << endl;
  }
  return 0;
}
