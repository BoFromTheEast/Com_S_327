#include <iostream>

void cswap(int *x, int *y)
{
  int tmp = *x;
  *x = *y;
  *y = tmp;
}

void cppswap(int &x, int &y)
{
  int tmp = x;
  x = y;
  y = tmp;
}

int main(int argc, char *argv[])
{
  int i = 0, j = 1;

  std::cout << "i: " << i << "\tj: " << j << std::endl;

  cswap(&i, &j);
  
  std::cout << "i: " << i << "\tj: " << j << std::endl;

  cppswap(i, j);
  
  std::cout << "i: " << i << "\tj: " << j << std::endl;

  return 0;
}
