#ifndef STRING327_H
#define STRING327_H

#include <iostream>

class string327 {
 private:
  char *str;
 public:
  string327();
  string327(const char *s);
  string327(const string327 &s);
  ~string327();
  int length() const;
  bool operator<(const string327 &rhs) const;
  bool operator>(const string327 &rhs) const;
  bool operator==(const string327 &rhs) const;
  bool operator!=(const string327 &rhs) const;
  bool operator<=(const string327 &rhs) const;
  bool operator>=(const string327 &rhs) const;
  string327 operator+(const string327 &rhs) const;
  string327 operator+(const char *rhs) const;
  string327 &operator+=(const string327 &rhs);
  string327 &operator+=(const char *rhs);
  string327 &operator=(const string327 &rhs);
  string327 &operator=(const char *rhs);
  char &operator[](const int i) const;
  const char *c_str() const;

  // Friends have access to our privates
  friend std::istream &operator>>(std::istream &lhs, const string327 &rhs);
};

std::ostream &operator<<(std::ostream &lhs, const string327 &rhs);

#endif
