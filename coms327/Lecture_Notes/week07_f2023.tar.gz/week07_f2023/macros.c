

/* Two kinds of macros: value-type, function-type. */

#define PI 3.1415926

#define add(x, y) (x + y)

#define min(x, y) (x < y ? x : y)

#define max(x, y) ({ \
  typeof (x) _x = x; \
  typeof (y) _y = y; \
  _x > _y ? _x : _y; \
})

#define stringify(x) #x

struct lutable_entry {
  char *name;
  void (*func)();
};

#define build_entry(x) { #x, x }

struct lutable_entry lookup_table[] = {
  /*
  { "a",    a    },
  { "c",    c    },
  { "foo",  foo  },
  { "go",   go   },
  { "stop", stop },
  */
  build_entry(a),
  build_entry(c),
  build_entry(foo),
  build_entry(go),
  build_entry(stop),
};

bsearch("c", lookup_table, num elements in table, size of an element, comparitor)->func()

PI;

#define concatenate(x) x ## foo

add(PI, 10) * 2;

min(4, 7);
min(really_expensive_function(), function_with_side_effects());
  
stringify(Hello World!);

concatenate(Hello);

enum trainer_type {
  trainer_hiker,
  trainer_rival,
  trainer_swimmer,
};

#define move(x) trainer_move_func[trainer_ ## x]()

move(rival);

#define FOO

#ifndef FOO_H
#define FOO_H


#endif
