#include <stdio.h>

static int foo; // Static globals are scope-limited to the
                // "compilation unit" (file).  It cannot be accessed
                // outside of this file (linker doesn't export the symbol).
                // Also applicable to functions.

int func()
{
  static int num_calls; // zero by placement ("by placement" because the linker
                        // puts this variable in the "data segment", which is
                        // initialized to all bits 0.

  return ++num_calls;
}

int main(int argc, char *argv[])
{
  int i;
  
  for (i = 0; i < 1000; i++) {
    printf("%d\n", func());
  }
}
