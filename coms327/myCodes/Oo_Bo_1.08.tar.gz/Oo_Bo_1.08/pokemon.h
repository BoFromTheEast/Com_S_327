#ifndef POKEMON_H
# define POKEMON_H
#pragma once
#include <string>
#include <array>

enum class pokemon_stat {
    HP,
    Attack,
    Defense,
    SpecialAttack,
    SpecialDefense,
    Speed
};

enum class pokemon_gender {
  Female,
  Male
};

class pokemon {
 private:
  int level;
  int pokemon_index;
  std::array<int, 4> move_index;
  int pokemon_species_index;
  std::array<int, 6> IV;
  std::array<int, 6> effective_stat;
  bool shiny;
  pokemon_gender gender;

 public:
  pokemon();
  explicit pokemon(int level);

  // Returns the species of the Pokemon as a string
  std::string getSpecies() const;

  // Returns the specified stat of the Pokemon
  int getStat(pokemon_stat stat) const;

  // Returns the gender of the Pokemon as a string ("Female" or "Male")
  std::string getGenderString() const;

  // Returns true if the Pokemon is shiny
  bool isShiny() const;

  // Returns the move at the specified index
  std::string getMove(std::size_t index) const;
};
#endif
