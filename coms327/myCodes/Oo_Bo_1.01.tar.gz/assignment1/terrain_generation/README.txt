Terrain Generation 1.01

The objective of the first assignment is to create a 24 by 80 terrain with 3 rows left for messages for the game.

For this assignment, I have not met the specification as there wasn't enough time for me to finish writing the program as I didn't quite
understand how to create the mountain and didn't have enough time to finish up on the trees.

Though I didn't finish up on the assignment, I have mangaged to meet some most of the specifications of the requirements.
The most imporatant functions and structs for this assignment are the following:

1. struct map - This struct is used to store the terrain, mountain and trees for the game.

2. struct character - This struct is used to store the character for the game.

3. struct characters defaultChar - This struct is used to store the default character for the game.

4. void map_border(struct map *border) - This struct is used to store the border for the game. with rows and columns that fill the inside with spaces.
And this struct created the borders for the map starting at the 3th rows and 1st columns all the way to 24th rows and 80th columns.

5. void objectPlacing(struct map *mapBorder, struct characters *terrainChar, char object, int size) - This functions is used to place the objects randomly in the map starting at 5th rows and
1st columns all the way to 24th rows and 80th columns.

6. void placeRoad(struct map *mapBorder, struct characters *terrainChar, char object) - this function is used to place the road for the game. It have two road where one is EW and one is NS. The roads are allowed to cross anything and they can cross each other.
the only thing the roads cannot cross is the Pokemon Center and the Pokemon Mart. The road is coded to go around these building.

7. void tallGrass(struct map *mapBorder, struct characters *terrainChar, char object) - this is function is used to place the tall grass and the tall grass is not allowed to be placed over the road, the Pokemon Center and the Pokemon Mart and the mountain.

8. void mountainAndBoulder(struct map *mapBorder, struct characters *terrainChar, char object) - This function was intended to create the mountain and the boulder. However, I didn't have enough time to finish up on this function since I couldn't figure out how to make the 
mountain not have a square shape. I managed to create the boulder and it is ranomized and all over the map with it not being allowed
to be placed over the road, the Pokemon Center and the Pokemon Mart and the mountain.

I should've try to understand how to make the mountain not have a square shape and I should've try to finish up on the trees. I think the mountain was the one that gave me the most problem as I had no idea
how to tackle it. Not sure if i had to do a CHANGELOG so I didn't ended up doing it.