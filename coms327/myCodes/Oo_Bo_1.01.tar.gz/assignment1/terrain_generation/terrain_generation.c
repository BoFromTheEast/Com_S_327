#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/*
The dimension is to be 80 x 24 but the 3 of the 24 is to be used for game message while the 24 -3 = 21 is the actual length for the map;
*/
struct map{
    char grid[24][80]; // 2d array of the map
};

/* This is to declare the characters variables
*/
struct characters{
    char tree, grass, clearing,roads, pokemonCenter, pokeMart,boulders;
};

/* This is to initilize the characters in the Character struct
*/
struct characters defaultChar = {
    .tree = '^',
    .boulders = '%',
    .clearing = '.',
    .roads = '#',
    .pokeMart = 'M',
    .pokemonCenter = 'C',
    .grass = ':'
};


/*
A map border created as soon as the map is to be generated 
*/
void map_border(struct map *border){
    int rows, columns; // the rows and columns of the map
    /*
    first three rows are supposed to be left empty
    */
    for(rows = 0; rows < 3; rows++){
        for(columns = 0; columns < 80; columns++){
            border->grid[rows][columns] = ' ';
        }
    }
   /*
    This is iterating through the map by going through each row and each column of the rows
    and checking if it is the first row or not to create a border
    and it leaves empty space if not first/last rows and columns
    */
    for(rows = 3; rows < 24; rows++){
        for(columns = 0; columns < 80; columns++){
            if(rows == 3 || rows == 23){
                border->grid[rows][columns] = '%';
            }
            else if(columns == 0 || columns == 79){
                border->grid[rows][columns] = '%';
            
            }
            else{
                border->grid[rows][columns] = '.';
            }
        }
    }
}

void objectPlacing(struct map *mapBorder, struct characters *terrainChar, char object, int size){
     int x = 0,y = 0;
        do {
        x = (rand() % (78 - size)) + 1;
        y = (rand() % (20 - size)) + 4;
        } while (mapBorder->grid[y][x] != terrainChar->clearing);

    for(int i = 0; i < size; ++i) {
        for(int j = 0; j < size; ++j) {
            mapBorder->grid[y + i][x + j] = object;
        }
    }
}

/* The roads are to be radomized and placed from the border of the map and to connect to the 
other side of the map. The road is allowed to overlap with other roads and other objects and also overwrite
the borders.
*/
void placeRoad(struct map *mapBorder, struct characters *terrainChar, char object) {
    int xRows,yRows, randomAmount;
    xRows = (rand() % 79) + 5;  // Random column
    yRows = (rand() % 21) + 4;  // Random row starting at 4 to leave the first 3 rows empty

    //vertical road
    for (int i = 3; i <= 24; i++) {  // Starting at 4 to leave the first 3 rows empty
        // Randomly decide if this section of the road will turn up or down
    int turn = rand() % 10;  // 10% chance to turn
    if (turn == 0) {
        randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
        yRows += randomAmount;  // Move the road up or down
        if (yRows < 4) yRows = 4;  // Don't go above the top boundary
        if (yRows > 21) yRows = 21;  // Don't go below the bottom boundary
        }
        // Place the road section
        if (xRows >= 0 && xRows < 80) {
            if(mapBorder->grid[i-1][xRows] != terrainChar->pokeMart && mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
            mapBorder->grid[i][xRows+randomAmount] = object;
            }else{
                mapBorder->grid[i][xRows+2] = object;
            }
        }
    }

    // Horizontal road with occasional turns
for (int i = 0; i < 80; i++) {
    // Randomly decide if this section of the road will turn up or down
    int turn = rand() % 10;  // 10% chance to turn
    if (turn == 0) {
        randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
        yRows += randomAmount;  // Move the road up or down
        if (yRows < 4) yRows = 4;  // Don't go above the top boundary
        if (yRows > 21) yRows = 21;  // Don't go below the bottom boundary
    }
    // Place the road section
    if (yRows >= 0 && yRows < 24) {
            if (mapBorder->grid[yRows][i] != terrainChar->pokeMart && mapBorder->grid[yRows][i] != terrainChar->pokemonCenter) {
                mapBorder->grid[yRows][i] = object;
            }
            else {
                mapBorder->grid[yRows+1][i] = object;
            }
        }
    }
}
/* The tall grass is to be placed randomly on the map and there need to be two patches of the tall grass
I intend to separate the map into two parts and place the box1 tall grass in the first box and the second box2 in the second box
I intend to use the randomizer to randomize the size of the tall grass and the location of the tall grass
*/
void tallGrass(struct map *mapBorder, struct characters *terrainChar, char object) {
    int x1, y1, x2, y2, size1, size2;

    // Randomize size of tall grass patches for box 1 and box 2
    size1 = (rand() % 10) + 5;  // Random size between 2 and 11
    size2 = (rand() % 10) + 5;  // Random size between 2 and 11

    // Randomize location for box 1 (left half of the map)
    do {
        x1 = (rand() % 38) + 1;
        y1 = (rand() % 19) + 4;
    } while (mapBorder->grid[y1][x1] != terrainChar->clearing);

    // Randomize location for box 2 (right half of the map)
    do {
        x2 = (rand() % 38) + 41;
        y2 = (rand() % 19) + 4;
    } while (mapBorder->grid[y2][x2] != terrainChar->clearing);
    // Place tall grass for box 1
    for (int i = 0; i < size1; ++i) {
        for (int j = 0; j < size1; ++j) {
            if(mapBorder->grid[y1 + i][x1 + j] != terrainChar->pokeMart && mapBorder->grid[y1 + i][x1 + j] != terrainChar->pokemonCenter && mapBorder->grid[y1 + i][x1 + j] != terrainChar->roads){
            if (y1 + i < 23 && x1 + j < 79) {
                mapBorder->grid[y1 + i][x1 + j] = object;
            }
        }else{
            break;
        }
        }
    }
    // Place tall grass for box 2
    for (int i = 0; i < size2; ++i) {
        for (int j = 0; j < size2; ++j) {
            if (y2 + i < 23 && x2 + j < 79) {
                if(mapBorder->grid[y2 + i][x2 + j] != terrainChar->pokeMart && mapBorder->grid[y2 + i][x2 + j] != terrainChar->pokemonCenter && mapBorder->grid[y2 + i][x2 + j] != terrainChar->roads){
                mapBorder->grid[y2 + i][x2 + j] = object;
            }
            }else{
                break;
            }
        }
    }
}


/* The boulders are to be placed randomly on the map and the mountains will be placed randomly on the map but not in a square shape
*/
void mountainAndBoulder(struct map *mapBorder, struct characters *terrainChar, char object) {
    int x = 0, y = 0;
    int boulders = (rand() % 10) + 10;  // Random number of boulders between 10 and 19
    
    // Randomly place boulders
    while (boulders >= 0) {
        x = (rand() % 79) + 1;
        y = (rand() % 20) + 4;
        
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
            boulders--;
        }
    }
}


void randomize(struct map *mapBorder, struct characters *terrainChar){

    tallGrass(mapBorder, terrainChar, terrainChar->grass);
    mountainAndBoulder(mapBorder, terrainChar, terrainChar->boulders);
    objectPlacing(mapBorder, terrainChar, terrainChar->pokeMart, 2);
    objectPlacing(mapBorder, terrainChar, terrainChar->pokemonCenter, 2);
    placeRoad(mapBorder, terrainChar,terrainChar->roads);
    

}


int main(int argc, char* argv[]){

// char input;
struct map border;
struct characters terrainChar = defaultChar;
srand(time(NULL));
int rows, columns;

    printf("generating terrain...\n");

    map_border(&border);
    randomize(&border, &terrainChar);
    

    for(rows = 0; rows < 24; rows++){
        for(columns = 0; columns < 80; columns++){
            printf("%c", border.grid[rows][columns]);
        }
        printf("\n");
    }
    

return 0;
}