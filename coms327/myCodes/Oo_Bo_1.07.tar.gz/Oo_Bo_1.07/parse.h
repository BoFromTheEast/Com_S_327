#ifndef PARSE_H
#define PARSE_H

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>

using namespace std;


class pokemon_t{
    public:
        //member variables
        int id;
        string identifier;
        int species_id;
        int height;
        int weight;
        int base_experience;
        int order;
        int is_default;

    //Default constructor
    pokemon_t(){}

    //Parameterized constructor
    pokemon_t
    (
        int id,
        string identifier,
        int species_id,
        int height,
        int weight,
        int base_experience,
        int order,
        int is_default
    ) : id(id), identifier(identifier), species_id(species_id), height(height),
        weight(weight), base_experience(base_experience), order(order),
        is_default(is_default) {}  // Used member initializer list for conciseness
};

class pokemove_t{
    public:
        int pokemon_id;
        int version_group_id;
        int move_id;
        int pokemon_move_method_id;
        int level;
        int order;
    //Default constructor
    pokemove_t()
    {
    
    }
    //Parameterized constructor
    pokemove_t
    (
        int pokemon_id,
        int version_group_id,
        int move_id,
        int pokemon_move_method_id,
        int level,
        int order
    ) : pokemon_id(pokemon_id), version_group_id(version_group_id), move_id(move_id),
        pokemon_move_method_id(pokemon_move_method_id), level(level), order(order){}

};

class move_t{
    public:
        //member variables
        int id;
        string identifier;
        int generation_id;
        int type_id;
        int power;
        int pp;
        int accuracy;
        int priority;
        int target_id;
        int damage_class_id;
        int effect_id;
        int effect_chance;
        int contest_type_id;
        int contest_effect_id;
        int super_contest_effect_id;
    //Default constructor
    move_t()
    {

    }
    //Parameterized constructor
    move_t
    (
        int id,
        string identifier,
        int generation_id,
        int type_id,
        int power,
        int pp,
        int accuracy,
        int priority,
        int target_id,
        int damage_class_id,
        int effect_id,
        int effect_chance,
        int contest_type_id,
        int contest_effect_id,
        int super_contest_effect_id
    ) : id(id), generation_id(generation_id), type_id(type_id), power(power),
        pp(pp), accuracy(accuracy), priority(priority), target_id(target_id),
        damage_class_id(damage_class_id), effect_id(effect_id),
        effect_chance(effect_chance), contest_type_id(contest_type_id),
        contest_effect_id(contest_effect_id),
        super_contest_effect_id(super_contest_effect_id){}

};

class pokemon_species_t{
    public:
        int id;
        string identifier;
        int generation_id;
        int evolves_from_species_id;
        int evolution_chain_id;
        int color_id;
        int shape_id;
        int habitat_id;
        int gender_rate;
        int capture_rate;
        int base_happiness;
        int is_baby;
        int hatch_counter;
        int has_gender_differences;
        int growth_rate_id;
        int forms_switchable;
        int is_legendary;
        int is_mythical;
        int order;
        int conquest_order;
    //Default constructor
    pokemon_species_t()
    {

    }
    //Parameterized constructor
    pokemon_species_t(
        int id,
        string identifier,
        int generation_id,
        int evolves_from_species_id,
        int evolution_chain_id,
        int color_id,
        int shape_id,
        int habitat_id,
        int gender_rate,
        int capture_rate,
        int base_happiness,
        int is_baby,
        int hatch_counter,
        int has_gender_differences,
        int growth_rate_id,
        int forms_switchable,
        int is_legendary,
        int is_mythical,
        int order,
        int conquest_order
    ) : 
        id(id), 
        identifier(identifier), 
        generation_id(generation_id), 
        evolves_from_species_id(evolves_from_species_id),
        evolution_chain_id(evolution_chain_id),
        color_id(color_id),
        shape_id(shape_id),
        habitat_id(habitat_id),
        gender_rate(gender_rate),
        capture_rate(capture_rate),
        base_happiness(base_happiness),
        is_baby(is_baby),
        hatch_counter(hatch_counter),
        has_gender_differences(has_gender_differences),
        growth_rate_id(growth_rate_id),
        forms_switchable(forms_switchable),
        is_legendary(is_legendary),
        is_mythical(is_mythical),
        order(order),
        conquest_order(conquest_order){}
};

class experience_t{
    public:
        int growth_rate_id;
        int level;
        int experience;
    //Default constructor
    experience_t()
    {

    }
    //Parameterized constructor
    experience_t
    (
        int growth_rate_id,
        int level,
        int experience
    ) : growth_rate_id(growth_rate_id), level(level), experience(experience){}
};

class pokemon_stats_t{
    public:
        int pokemon_id;
        int stat_id;
        int base_stat;
        int effort;
    //Default constructor
    pokemon_stats_t()
    {

    }
    //Parameterized constructor
    pokemon_stats_t
    (
        int pokemon_id,
        int stat_id,
        int base_stat,
        int effort
    ) : pokemon_id(pokemon_id), stat_id(stat_id), base_stat(base_stat), effort(effort){}

};

class stats_t{
    public:
        int id;
        int damage_class_id;
        string identifier;
        int is_battle_only;
        int game_index;
    //Default constructor
    stats_t(){}

    //Parameterized constructor
    stats_t
    (
        int id,
        int damage_class_id,
        string identifier,
        int is_battle_only,
        int game_index
    ) : id(id), damage_class_id(damage_class_id), identifier(identifier),
        is_battle_only(is_battle_only), game_index(game_index){}

    
};

class poketypes_t{
    public:
        int pokemon_id;
        int type_id;
        int slot;
    //Default constructor
    poketypes_t()
    {

    }
    //Parameterized constructor
    poketypes_t
    (
        int pokemon_id,
        int type_id,
        int slot
    ) : pokemon_id(pokemon_id), type_id(type_id), slot(slot){}

};


#endif