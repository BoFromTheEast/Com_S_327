#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sys/stat.h>
#include <climits>
#include <iostream>
#include <fstream>



#include "parse.h"

pokemon_t pokemon[1093];
pokemove_t pokeMove[528239];
move_t moves_t[845];
char* types[19];
pokemon_species_t species[899];

experience_t experience[601];
pokemon_stats_t pokestats[6553];
poketypes_t poketypes[1676];
stats_t stats[9];


char* getCSVPath(){
    struct stat buf; //stat struct
    char* prefix; //prefix to the csv files
    const char* home = getenv("HOME");

    // Check if HOME environment variable is set
    if (!home) {
        fprintf(stderr, "HOME environment variable not set!\n");
        return NULL;
    }

    int i = strlen(home) + strlen("/.poke327/pokedex/pokedex/data/csv/") + 1;
    prefix = (char *) malloc(i);
    if (!prefix) {
        fprintf(stderr, "Memory allocation failed!\n");
        return NULL;
    }

    strcpy(prefix, home);
    strcat(prefix, "/.poke327/pokedex/pokedex/data/csv/");

    // Check if the directory exists using stat
    if (stat(prefix, &buf) == 0) {
        return prefix;
    } else {
        free(prefix);
        if (stat("/share/cs327", &buf) == 0) {
            return strdup("/share/cs327/pokedex/pokedex/data/csv/");
        }
        // an optional third path:
        // else if (stat("/your/third/path/here/", &buf) == 0) {
        //     return strdup("/your/third/path/here/");
        // }
    }
    
    return NULL;
}

void parse(string input,bool print){

    char* path = getCSVPath(); //get the path to the csv files
    char* temp;
    int i;

    if(!path){ //if the path is null, then the csv files do not exist
        cout << "CSV files do not exist" << endl;
        return;
    }

    // int prefixlen = strlen(path);

    string fullPath;
    if (input == "pokemon") {
        fullPath = string(path) + "pokemon.csv";

        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if (!f) {
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 80, f);

        for(i = 1; i < 528239; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            
            pokemon[i].id = atoi(strtok(line, ","));
            pokemon[i].identifier = std::string(strtok(NULL, ",")).substr(0,30);
            pokemon[i].species_id = atoi(strtok(NULL, ","));
            pokemon[i].height = atoi(strtok(NULL, ","));
            pokemon[i].weight = atoi(strtok(NULL, ","));
            pokemon[i].base_experience = atoi(strtok(NULL, ","));
            pokemon[i].order = atoi(strtok(NULL, ","));
            pokemon[i].is_default = atoi(strtok(NULL, ","));
        }

        fclose(f);
        
            if (print) {
            f = fopen("pokemon.csv", "w");
            for (i = 1; i < 1093; i++) {
                fprintf(f, "%s,%s,%s,%s,%s,%s,%s,%s\n",
                    to_string(pokemon[i].id).c_str(),
                    pokemon[i].identifier.c_str(),
                    to_string(pokemon[i].species_id).c_str(),
                    to_string(pokemon[i].height).c_str(),
                    to_string(pokemon[i].weight).c_str(),
                    to_string(pokemon[i].base_experience).c_str(),
                    to_string(pokemon[i].order).c_str(),
                    to_string(pokemon[i].is_default).c_str()
                );
            }
            fclose(f);
        }
        
    } else if (input == "moves") {
        fullPath = string(path) + "moves.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if (!f) {
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);

        for(i = 1; i < 845; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
                moves_t[i].id = atoi((temp = strtok(line, ",")));
                moves_t[i].identifier = std::string(temp = strtok(NULL, ","));
                temp = strtok(NULL, ",");
                moves_t[i].generation_id = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].type_id = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].power = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].pp = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].accuracy = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].priority = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].target_id = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].damage_class_id = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].effect_id = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].effect_chance =(temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].contest_type_id = (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].contest_effect_id =  (temp && *temp) ? atoi(temp) : INT_MAX;
                temp = strtok(NULL, ",");
                moves_t[i].super_contest_effect_id = (temp && *temp != '\n') ? atoi(temp) : INT_MAX;
        }

        fclose(f);
        
            if (print) {
            f = fopen("moves.csv", "w");
            for (i = 1; i < 845; i++) {
                fprintf(f, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                    to_string(moves_t[i].id).c_str(),
                    moves_t[i].identifier.c_str(),
                    to_string(moves_t[i].generation_id).c_str(),
                    to_string(moves_t[i].type_id).c_str(),
                    to_string(moves_t[i].power).c_str(),
                    to_string(moves_t[i].pp).c_str(),
                    to_string(moves_t[i].accuracy).c_str(),
                    to_string(moves_t[i].priority).c_str(),
                    to_string(moves_t[i].target_id).c_str(),
                    to_string(moves_t[i].damage_class_id).c_str(),
                    to_string(moves_t[i].effect_id).c_str(),
                    to_string(moves_t[i].effect_chance).c_str(),
                    to_string(moves_t[i].contest_type_id).c_str(),
                    to_string(moves_t[i].contest_effect_id).c_str(),
                    to_string(moves_t[i].super_contest_effect_id).c_str()
                );
            }
            fclose(f);
        }
        
    } else if (input == "pokemoves") {
        fullPath = string(path) + "pokemon_moves.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if (!f) {
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);
        for(i = 1; i < 528239; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            temp = strtok(line, ",");
            pokeMove[i].pokemon_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL, ",");
            pokeMove[i].version_group_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL, ",");
            pokeMove[i].move_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL, ",");
            pokeMove[i].pokemon_move_method_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL, ",");
            pokeMove[i].level = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL, ",");
            pokeMove[i].order = (temp && *temp) ? atoi(temp) : INT_MAX;
        }

        fclose(f);
        
            if (print) {
            f = fopen("pokemoves.csv", "w");
            for (i = 1; i < 528239; i++) {
                fprintf(f, "%s,%s,%s,%s,%s,%s\n",
                    to_string(pokeMove[i].pokemon_id).c_str(),
                    to_string(pokeMove[i].version_group_id).c_str(),
                    to_string(pokeMove[i].move_id).c_str(),
                    to_string(pokeMove[i].pokemon_move_method_id).c_str(),
                    to_string(pokeMove[i].level).c_str(),
                    to_string(pokeMove[i].order).c_str()
                );
            }
            fclose(f);
        }

    } else if (input == "pokemon_species") {
        fullPath = string(path) + "pokemon_species.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if (!f) {
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);
        for(i = 1; i < 899; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            
            species[i].id = atoi((temp = strtok(line, ",")));
            temp = strtok(NULL,",");
            species[i].identifier = std::string(temp);
            temp = strtok(NULL,",");
            species[i].generation_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            species[i].evolves_from_species_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            species[i].evolution_chain_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            species[i].color_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            species[i].shape_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            species[i].habitat_id = (temp && *temp) ? atoi(temp) : INT_MAX;
        }
        fclose(f);

        if (print) {
            f = fopen("species.csv", "w");
            for (i = 1; i < 899; i++) {
                fprintf(f, "%s,%s,%s,%s,%s,%s,%s,%s\n",
                    to_string(species[i].id).c_str(),
                    species[i].identifier.c_str(),
                    to_string(species[i].generation_id).c_str(),
                    to_string(species[i].evolves_from_species_id).c_str(),
                    to_string(species[i].evolution_chain_id).c_str(),
                    to_string(species[i].color_id).c_str(),
                    to_string(species[i].shape_id).c_str(),
                    to_string(species[i].habitat_id).c_str()
                );
            }
            fclose(f);
        }
        
    } else if (input == "experience") {
        fullPath = string(path) + "experience.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if(!f){
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);
        for(i = 1; i < 601; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            experience[i].growth_rate_id = atoi((temp = strtok(line, ",")));
            temp = strtok(NULL,",");
            experience[i].level = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            experience[i].experience = (temp && *temp) ? atoi(temp) : INT_MAX;
        }
        fclose(f);

        if (print) {
            f = fopen("experience.csv", "w");
            for (i = 1; i < 601; i++) {
                fprintf(f, "%s,%s,%s\n",
                    to_string(experience[i].growth_rate_id).c_str(),
                    to_string(experience[i].level).c_str(),
                    to_string(experience[i].experience).c_str()
                );
            }
            fclose(f);
        }

    } else if (input == "pokemonstats") {
        fullPath = string(path) + "pokemon_stats.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if(!f){
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);

        for(i = 1; i < 6553; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            pokestats[i].pokemon_id = atoi((temp = strtok(line, ",")));
            temp = strtok(NULL,",");
            pokestats[i].stat_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            pokestats[i].base_stat = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            pokestats[i].effort = (temp && *temp) ? atoi(temp) : INT_MAX;
        }
        fclose(f);

        if (print) {
            f = fopen("pokemonstats.csv", "w");
            for (i = 1; i < 6553; i++) {
                fprintf(f, "%s,%s,%s,%s\n",
                    to_string(pokestats[i].pokemon_id).c_str(),
                    to_string(pokestats[i].stat_id).c_str(),
                    to_string(pokestats[i].base_stat).c_str(),
                    to_string(pokestats[i].effort).c_str()
                );
            }
            fclose(f);
        }
        
    } else if (input == "stats") {
        fullPath = string(path) + "stats.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if(!f){
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);

        for(i = 1; i < 9; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            stats[i].id = atoi((temp = strtok(line, ",")));
            temp = strtok(NULL,",");
            stats[i].damage_class_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            stats[i].identifier = std::string(temp);
            temp = strtok(NULL,",");
            stats[i].is_battle_only = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            stats[i].game_index = (temp && *temp) ? atoi(temp) : INT_MAX;
        }
        fclose(f);

        if (print) {
            f = fopen("stats.csv", "w");
            for (i = 1; i < 9; i++) {
                fprintf(f, "%s,%s,%s,%s,%s\n",
                    to_string(stats[i].id).c_str(),
                    to_string(stats[i].damage_class_id).c_str(),
                    stats[i].identifier.c_str(),
                    to_string(stats[i].is_battle_only).c_str(),
                    to_string(stats[i].game_index).c_str()
                );
            }
            fclose(f);
        }
    } else if (input == "poketypes") {
        fullPath = string(path) + "pokemon_types.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if(!f){
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);
        
        for(i = 1; i < 1676; i++){
            if (fgets(line, 800, f) == NULL) {
                break;  // error 
            }
            poketypes[i].pokemon_id = atoi((temp = strtok(line, ",")));
            temp = strtok(NULL,",");
            poketypes[i].type_id = (temp && *temp) ? atoi(temp) : INT_MAX;
            temp = strtok(NULL,",");
            poketypes[i].slot = (temp && *temp) ? atoi(temp) : INT_MAX;
        }
        fclose(f);

        if (print) {
            f = fopen("pokemontypes.csv", "w");
            for (i = 1; i < 1676; i++) {
                fprintf(f, "%s,%s,%s\n",
                    to_string(poketypes[i].pokemon_id).c_str(),
                    to_string(poketypes[i].type_id).c_str(),
                    to_string(poketypes[i].slot).c_str()
                );
            }
            fclose(f);
        }
    
    } else if (input == "types") {
        fullPath = string(path) + "type_names.csv";
        FILE *f = fopen(fullPath.c_str(), "r");
        char line[800];

        if(!f){
            cout << "Error: Could not open " << fullPath << endl;
            free(path);
            return;
        }
        fgets(line, 800, f);

        for (i = 1; i < 19; i++) {
            char *comma_ptr = NULL;
            int comma_count = 0;
            while (fgets(line, 800, f) != NULL) { // Read lines until it find what it's looking for
                for (char *p = line; *p; p++) {
                    if (*p == ',') {
                        comma_count++;
                        if (comma_count == 2) { // found the second comma
                            comma_ptr = p;
                            break;
                        }
                    }
                }
                if (comma_ptr != NULL) { // We've found the correct position in the line
                    break;
                }
            }
            if (comma_ptr != NULL) {
                *comma_ptr = '\0'; // Null-terminate at the second comma
                types[i] = strdup(comma_ptr + 1); // Copy the data after the comma
            } else {
                // Handle error: not enough commas were found
            }
        }
        fclose(f);

        if (print) {
            f = fopen("type_names.csv", "w");
            for (i = 1; i < 19; i++) {
            fprintf(f, "%s\n", types[i]);
            }
            fclose(f);
        }
        

    } else if (input == "all") {
        // Handle all files.
    } else {
        cout << "Invalid input" << endl;
        free(path);
        return;
    }

    ifstream file(fullPath);
    if (!file.is_open()) {
        cout << "Error: Could not open " << fullPath << endl;
        free(path);
        return;
    }

    string line;
    while (getline(file, line)) {
        // Parse each line. This is where you'd handle the CSV parsing logic.
        cout << line << endl; // For now, just print each line.
    }

    file.close();
    free(path);
}






