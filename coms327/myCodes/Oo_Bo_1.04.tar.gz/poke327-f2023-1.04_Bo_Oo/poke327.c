#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <sys/time.h>
#include <assert.h>
#include <unistd.h>
#include "heap.h"

#define malloc(size) ({          \
  void *_tmp;                    \
  assert((_tmp = malloc(size))); \
  _tmp;                          \
})

typedef struct path { // path struct to hold position and cost
  heap_node_t *hn; // heap node
  uint8_t pos[2]; // position
  uint8_t from[2]; // from
  int32_t cost; // cost
} path_t; // path struct

typedef enum dim {
  dim_x,
  dim_y,
  num_dims
} dim_t;

typedef int16_t pair_t[num_dims];

#define MAP_X              80
#define MAP_Y              21
#define MIN_TREES          10
#define MIN_BOULDERS       10
#define TREE_PROB          95
#define BOULDER_PROB       95
#define WORLD_SIZE         401

#define MOUNTAIN_SYMBOL       '%'
#define BOULDER_SYMBOL        '0'
#define TREE_SYMBOL           '4'
#define FOREST_SYMBOL         '^'
#define GATE_SYMBOL           '#'
#define PATH_SYMBOL           '#'
#define POKEMART_SYMBOL       'M'
#define POKEMON_CENTER_SYMBOL 'C'
#define TALL_GRASS_SYMBOL     ':'
#define SHORT_GRASS_SYMBOL    '.'
#define WATER_SYMBOL          '~'
#define ERROR_SYMBOL          '&'

#define mappair(pair) (m->map[pair[dim_y]][pair[dim_x]])
#define mapxy(x, y) (m->map[y][x])
#define heightpair(pair) (m->height[pair[dim_y]][pair[dim_x]])
#define heightxy(x, y) (m->height[y][x])

typedef enum __attribute__ ((__packed__)) terrain_type {
  ter_boulder,
  ter_tree,
  ter_path,
  ter_mart,
  ter_center,
  ter_grass,
  ter_clearing,
  ter_mountain,
  ter_forest,
  ter_water,
  ter_gate,
  num_terrain_types,
  ter_debug
} terrain_type_t;

typedef enum __attribute__ ((__packed__)) character_type {
  char_pc,
  char_hiker,
  char_rival,
  char_sentry,
  char_pacer ,
  char_wanderer,
  char_explorer,
  char_swimmer,
  char_other,
  num_character_types
} character_type_t;

typedef struct pc {
  pair_t pos;
} pc_t;

// added trainer struct to hold position and path cost for the trainers
typedef struct trainers{
    char trainers;  // type of trainers
    pair_t pos;                 // position
    int cost;                   // path cost
    int dir;                    // dir
    int place;                  // place
} trainers_t; 

typedef struct map {
  terrain_type_t map[MAP_Y][MAP_X];
  uint8_t height[MAP_Y][MAP_X];
  int8_t n, s, e, w;
} map_t;

typedef struct queue_node {
  int x, y;
  struct queue_node *next;
} queue_node_t;

typedef struct world {
  map_t *world[WORLD_SIZE][WORLD_SIZE];
  pair_t cur_idx;
  map_t *cur_map;
  /* Place distance maps in world, not map, since *
   * we only need one pair at any given time.     */
  int hiker_dist[MAP_Y][MAP_X];//gg
  int rival_dist[MAP_Y][MAP_X];//gg
  pc_t pc;
} world_t;



/* Even unallocated, a WORLD_SIZE x WORLD_SIZE array of pointers is a very *
 * large thing to put on the stack.  To avoid that, world is a global.     */
world_t world;

int numtrainers;   // number of trainers
char map[MAP_Y][MAP_X];  // map to hold the terrain features and to print out


// static int32_t trainers; // number of trainers


/* Just to make the following table fit in 80 columns */
#define IM INT_MAX
int32_t move_cost[num_character_types][num_terrain_types] = {
//  boulder,tree,path,mart,center,grass,clearing,mountain,forest,water,gate
  { IM, IM, 10, 10, 10, 20, 10, IM, IM, IM, 10 }, //PC
  { IM, IM, 10, 50, 50, 15, 10, 15, 15, IM, IM }, //HIKER
  { IM, IM, 10, 50, 50, 20, 10, IM, IM, IM, IM }, //RIVAL
  { IM, IM, IM, IM, IM, IM, IM, IM, IM,  7, IM }, //SWIMMER
  { IM, IM, 10, 50, 50, 20, 10, IM, IM, IM, IM }  //OTHER
};
#undef IM

static int32_t compareTrainers(const void *key, const void *with){ // compare function for trainers
  return ((trainers_t*) key)->cost - ((trainers_t*) with)->cost; // return the difference between the path costs
}

static int32_t path_cmp(const void *key, const void *with) { // compare function for path
  return ((path_t *) key)->cost - ((path_t *) with)->cost; // return the difference between the costs
}

static int32_t edge_penalty(int8_t x, int8_t y) // penalty for edge
{
  return (x == 1 || y == 1 || x == MAP_X - 2 || y == MAP_Y - 2) ? 2 : 1; // if on edge, penalty is 2, else 1
}

static void dijkstra_path(map_t *m, pair_t from, pair_t to) // dijkstra's algorithm for path
{
  static path_t path[MAP_Y][MAP_X], *p;
  static uint32_t initialized = 0;
  heap_t h; // heap
  uint32_t x, y; // x and y coordinates

  if (!initialized) { // if not initialized
    for (y = 0; y < MAP_Y; y++) {
      for (x = 0; x < MAP_X; x++) {
        path[y][x].pos[dim_y] = y; // set y coordinate
        path[y][x].pos[dim_x] = x; // set x coordinate
      }
    }
    initialized = 1;
  }
  
  for (y = 0; y < MAP_Y; y++) { 
    for (x = 0; x < MAP_X; x++) {
      path[y][x].cost = INT_MAX; // set cost to max
    }
  }

  path[from[dim_y]][from[dim_x]].cost = 0; // set cost to 0

  heap_init(&h, path_cmp, NULL); // initialize heap for path
  // heap_init(&h, compareTrainers, NULL); // initialize heap for trainers

  for (y = 1; y < MAP_Y - 1; y++) {
    for (x = 1; x < MAP_X - 1; x++) {
      path[y][x].hn = heap_insert(&h, &path[y][x]);
    }
  }

  while ((p = heap_remove_min(&h))) {
    p->hn = NULL;

    if ((p->pos[dim_y] == to[dim_y]) && p->pos[dim_x] == to[dim_x]) {
      for (x = to[dim_x], y = to[dim_y];
           (x != from[dim_x]) || (y != from[dim_y]);
           p = &path[y][x], x = p->from[dim_x], y = p->from[dim_y]) {
        /* Don't overwrite the gate */
        if (x != to[dim_x] || y != to[dim_y]) {
          mapxy(x, y) = ter_path;
          heightxy(x, y) = 0;
        }
      }
      heap_delete(&h);
      return;
    }

    if ((path[p->pos[dim_y] - 1][p->pos[dim_x]    ].hn) &&
        (path[p->pos[dim_y] - 1][p->pos[dim_x]    ].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x], p->pos[dim_y] - 1)))) {
      path[p->pos[dim_y] - 1][p->pos[dim_x]    ].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x], p->pos[dim_y] - 1));
      path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y] - 1]
                                           [p->pos[dim_x]    ].hn);
    }
    if ((path[p->pos[dim_y]    ][p->pos[dim_x] - 1].hn) &&
        (path[p->pos[dim_y]    ][p->pos[dim_x] - 1].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x] - 1, p->pos[dim_y])))) {
      path[p->pos[dim_y]][p->pos[dim_x] - 1].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x] - 1, p->pos[dim_y]));
      path[p->pos[dim_y]    ][p->pos[dim_x] - 1].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y]    ][p->pos[dim_x] - 1].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y]    ]
                                           [p->pos[dim_x] - 1].hn);
    }
    if ((path[p->pos[dim_y]    ][p->pos[dim_x] + 1].hn) &&
        (path[p->pos[dim_y]    ][p->pos[dim_x] + 1].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x] + 1, p->pos[dim_y])))) {
      path[p->pos[dim_y]][p->pos[dim_x] + 1].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x] + 1, p->pos[dim_y]));
      path[p->pos[dim_y]    ][p->pos[dim_x] + 1].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y]    ][p->pos[dim_x] + 1].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y]    ]
                                           [p->pos[dim_x] + 1].hn);
    }
    if ((path[p->pos[dim_y] + 1][p->pos[dim_x]    ].hn) &&
        (path[p->pos[dim_y] + 1][p->pos[dim_x]    ].cost >
         ((p->cost + heightpair(p->pos)) *
          edge_penalty(p->pos[dim_x], p->pos[dim_y] + 1)))) {
      path[p->pos[dim_y] + 1][p->pos[dim_x]    ].cost =
        ((p->cost + heightpair(p->pos)) *
         edge_penalty(p->pos[dim_x], p->pos[dim_y] + 1));
      path[p->pos[dim_y] + 1][p->pos[dim_x]    ].from[dim_y] = p->pos[dim_y];
      path[p->pos[dim_y] + 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      heap_decrease_key_no_replace(&h, path[p->pos[dim_y] + 1]
                                           [p->pos[dim_x]    ].hn);
    }
  }
}

static int build_paths(map_t *m)
{
  pair_t from, to;

  /*  printf("%d %d %d %d\n", m->n, m->s, m->e, m->w);*/

  if (m->e != -1 && m->w != -1) {
    from[dim_x] = 1;
    to[dim_x] = MAP_X - 2;
    from[dim_y] = m->w;
    to[dim_y] = m->e;

    dijkstra_path(m, from, to);
  }

  if (m->n != -1 && m->s != -1) {
    from[dim_y] = 1;
    to[dim_y] = MAP_Y - 2;
    from[dim_x] = m->n;
    to[dim_x] = m->s;

    dijkstra_path(m, from, to);
  }

  if (m->e == -1) {
    if (m->s == -1) {
      from[dim_x] = 1;
      from[dim_y] = m->w;
      to[dim_x] = m->n;
      to[dim_y] = 1;
    } else {
      from[dim_x] = 1;
      from[dim_y] = m->w;
      to[dim_x] = m->s;
      to[dim_y] = MAP_Y - 2;
    }

    dijkstra_path(m, from, to);
  }

  if (m->w == -1) {
    if (m->s == -1) {
      from[dim_x] = MAP_X - 2;
      from[dim_y] = m->e;
      to[dim_x] = m->n;
      to[dim_y] = 1;
    } else {
      from[dim_x] = MAP_X - 2;
      from[dim_y] = m->e;
      to[dim_x] = m->s;
      to[dim_y] = MAP_Y - 2;
    }

    dijkstra_path(m, from, to);
  }

  if (m->n == -1) {
    if (m->e == -1) {
      from[dim_x] = 1;
      from[dim_y] = m->w;
      to[dim_x] = m->s;
      to[dim_y] = MAP_Y - 2;
    } else {
      from[dim_x] = MAP_X - 2;
      from[dim_y] = m->e;
      to[dim_x] = m->s;
      to[dim_y] = MAP_Y - 2;
    }

    dijkstra_path(m, from, to);
  }

  if (m->s == -1) {
    if (m->e == -1) {
      from[dim_x] = 1;
      from[dim_y] = m->w;
      to[dim_x] = m->n;
      to[dim_y] = 1;
    } else {
      from[dim_x] = MAP_X - 2;
      from[dim_y] = m->e;
      to[dim_x] = m->n;
      to[dim_y] = 1;
    }

    dijkstra_path(m, from, to);
  }

  return 0;
}

static int gaussian[5][5] = { // gaussian convolution
  {  1,  4,  7,  4,  1 },
  {  4, 16, 26, 16,  4 },
  {  7, 26, 41, 26,  7 },
  {  4, 16, 26, 16,  4 },
  {  1,  4,  7,  4,  1 }
};

static int smooth_height(map_t *m)
{
  int32_t i, x, y;
  int32_t s, t, p, q;
  queue_node_t *head, *tail, *tmp;
  /*  FILE *out;*/
  uint8_t height[MAP_Y][MAP_X];

  memset(&height, 0, sizeof (height));

  /* Seed with some values */
  for (i = 1; i < 255; i += 20) {
    do {
      x = rand() % MAP_X;
      y = rand() % MAP_Y;
    } while (height[y][x]);
    height[y][x] = i;
    if (i == 1) {
      head = tail = malloc(sizeof (*tail));
    } else {
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
    }
    tail->next = NULL;
    tail->x = x;
    tail->y = y;
  }

  /*
  out = fopen("seeded.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&height, sizeof (height), 1, out);
  fclose(out);
  */
  
  /* Diffuse the vaules to fill the space */
  while (head) {
    x = head->x;
    y = head->y;
    i = height[y][x];

    if (x - 1 >= 0 && y - 1 >= 0 && !height[y - 1][x - 1]) {
      height[y - 1][x - 1] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y - 1;
    }
    if (x - 1 >= 0 && !height[y][x - 1]) {
      height[y][x - 1] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y;
    }
    if (x - 1 >= 0 && y + 1 < MAP_Y && !height[y + 1][x - 1]) {
      height[y + 1][x - 1] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x - 1;
      tail->y = y + 1;
    }
    if (y - 1 >= 0 && !height[y - 1][x]) {
      height[y - 1][x] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x;
      tail->y = y - 1;
    }
    if (y + 1 < MAP_Y && !height[y + 1][x]) {
      height[y + 1][x] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x;
      tail->y = y + 1;
    }
    if (x + 1 < MAP_X && y - 1 >= 0 && !height[y - 1][x + 1]) {
      height[y - 1][x + 1] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y - 1;
    }
    if (x + 1 < MAP_X && !height[y][x + 1]) {
      height[y][x + 1] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y;
    }
    if (x + 1 < MAP_X && y + 1 < MAP_Y && !height[y + 1][x + 1]) {
      height[y + 1][x + 1] = i;
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
      tail->next = NULL;
      tail->x = x + 1;
      tail->y = y + 1;
    }

    tmp = head;
    head = head->next;
    free(tmp);
  }

  /* And smooth it a bit with a gaussian convolution */
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      for (s = t = p = 0; p < 5; p++) {
        for (q = 0; q < 5; q++) {
          if (y + (p - 2) >= 0 && y + (p - 2) < MAP_Y &&
              x + (q - 2) >= 0 && x + (q - 2) < MAP_X) {
            s += gaussian[p][q];
            t += height[y + (p - 2)][x + (q - 2)] * gaussian[p][q];
          }
        }
      }
      m->height[y][x] = t / s;
    }
  }
  /* Let's do it again, until it's smooth like Kenny G. */
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      for (s = t = p = 0; p < 5; p++) {
        for (q = 0; q < 5; q++) {
          if (y + (p - 2) >= 0 && y + (p - 2) < MAP_Y &&
              x + (q - 2) >= 0 && x + (q - 2) < MAP_X) {
            s += gaussian[p][q];
            t += height[y + (p - 2)][x + (q - 2)] * gaussian[p][q];
          }
        }
      }
      m->height[y][x] = t / s;
    }
  }

  /*
  out = fopen("diffused.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&height, sizeof (height), 1, out);
  fclose(out);

  out = fopen("smoothed.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->height, sizeof (m->height), 1, out);
  fclose(out);
  */

  return 0;
}

static void find_building_location(map_t *m, pair_t p) // find building location
{
  do {
    p[dim_x] = rand() % (MAP_X - 3) + 1;
    p[dim_y] = rand() % (MAP_Y - 3) + 1;

    if ((((mapxy(p[dim_x] - 1, p[dim_y]    ) == ter_path)     &&
          (mapxy(p[dim_x] - 1, p[dim_y] + 1) == ter_path))    ||
         ((mapxy(p[dim_x] + 2, p[dim_y]    ) == ter_path)     &&
          (mapxy(p[dim_x] + 2, p[dim_y] + 1) == ter_path))    ||
         ((mapxy(p[dim_x]    , p[dim_y] - 1) == ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] - 1) == ter_path))    ||
         ((mapxy(p[dim_x]    , p[dim_y] + 2) == ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 2) == ter_path)))   &&
        (((mapxy(p[dim_x]    , p[dim_y]    ) != ter_mart)     &&
          (mapxy(p[dim_x]    , p[dim_y]    ) != ter_center)   &&
          (mapxy(p[dim_x] + 1, p[dim_y]    ) != ter_mart)     &&
          (mapxy(p[dim_x] + 1, p[dim_y]    ) != ter_center)   &&
          (mapxy(p[dim_x]    , p[dim_y] + 1) != ter_mart)     &&
          (mapxy(p[dim_x]    , p[dim_y] + 1) != ter_center)   &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 1) != ter_mart)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 1) != ter_center))) &&
        (((mapxy(p[dim_x]    , p[dim_y]    ) != ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y]    ) != ter_path)     &&
          (mapxy(p[dim_x]    , p[dim_y] + 1) != ter_path)     &&
          (mapxy(p[dim_x] + 1, p[dim_y] + 1) != ter_path)))) {
          break;
    }
  } while (1);
}

static int place_pokemart(map_t *m)
{
  pair_t p;

  find_building_location(m, p);

  mapxy(p[dim_x]    , p[dim_y]    ) = ter_mart;
  mapxy(p[dim_x] + 1, p[dim_y]    ) = ter_mart;
  mapxy(p[dim_x]    , p[dim_y] + 1) = ter_mart;
  mapxy(p[dim_x] + 1, p[dim_y] + 1) = ter_mart;

  return 0;
}

static int place_center(map_t *m) // place poke center
{  pair_t p;

  find_building_location(m, p);

  mapxy(p[dim_x]    , p[dim_y]    ) = ter_center;
  mapxy(p[dim_x] + 1, p[dim_y]    ) = ter_center;
  mapxy(p[dim_x]    , p[dim_y] + 1) = ter_center;
  mapxy(p[dim_x] + 1, p[dim_y] + 1) = ter_center;

  return 0;
}

/* Chooses tree or boulder for border cell.  Choice is biased by dominance *
 * of neighboring cells.                                                   */
static terrain_type_t border_type(map_t *m, int32_t x, int32_t y)
{
  int32_t p, q;
  int32_t r, t;
  int32_t miny, minx, maxy, maxx;
  
  r = t = 0;
  
  miny = y - 1 >= 0 ? y - 1 : 0;
  maxy = y + 1 <= MAP_Y ? y + 1: MAP_Y;
  minx = x - 1 >= 0 ? x - 1 : 0;
  maxx = x + 1 <= MAP_X ? x + 1: MAP_X;

  for (q = miny; q < maxy; q++) {
    for (p = minx; p < maxx; p++) {
      if (q != y || p != x) {
        if (m->map[q][p] == ter_mountain ||
            m->map[q][p] == ter_boulder) {
          r++;
        } else if (m->map[q][p] == ter_forest ||
                   m->map[q][p] == ter_tree) {
          t++;
        }
      }
    }
  }
  
  if (t == r) {
    return rand() & 1 ? ter_boulder : ter_tree;
  } else if (t > r) {
    if (rand() % 10) {
      return ter_tree;
    } else {
      return ter_boulder;
    }
  } else {
    if (rand() % 10) {
      return ter_boulder;
    } else {
      return ter_tree;
    }
  }
}

static int map_terrain(map_t *m, int8_t n, int8_t s, int8_t e, int8_t w)
{
  int32_t i, x, y;
  queue_node_t *head, *tail, *tmp;
  //  FILE *out;
  int num_grass, num_clearing, num_mountain, num_forest, num_water, num_total;
  terrain_type_t type;
  int added_current = 0;
  
  num_grass = rand() % 4 + 2;
  num_clearing = rand() % 4 + 2;
  num_mountain = rand() % 2 + 1;
  num_forest = rand() % 2 + 1;
  num_water = rand() % 2 + 1;
  num_total = num_grass + num_clearing + num_mountain + num_forest + num_water;

  memset(&m->map, 0, sizeof (m->map));

  /* Seed with some values */
  for (i = 0; i < num_total; i++) {
    do {
      x = rand() % MAP_X;
      y = rand() % MAP_Y;
    } while (m->map[y][x]);
    if (i == 0) {
      type = ter_grass;
    } else if (i == num_grass) {
      type = ter_clearing;
    } else if (i == num_grass + num_clearing) {
      type = ter_mountain;
    } else if (i == num_grass + num_clearing + num_mountain) {
      type = ter_forest;
    } else if (i == num_grass + num_clearing + num_mountain + num_forest) {
      type = ter_water;
    }
    m->map[y][x] = type;
    if (i == 0) {
      head = tail = malloc(sizeof (*tail));
    } else {
      tail->next = malloc(sizeof (*tail));
      tail = tail->next;
    }
    tail->next = NULL;
    tail->x = x;
    tail->y = y;
  }

  /*
  out = fopen("seeded.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->map, sizeof (m->map), 1, out);
  fclose(out);
  */

  /* Diffuse the vaules to fill the space */
  while (head) {
    x = head->x;
    y = head->y;
    i = m->map[y][x];
    
    if (x - 1 >= 0 && !m->map[y][x - 1]) {
      if ((rand() % 100) < 80) {
        m->map[y][x - 1] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x - 1;
        tail->y = y;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (y - 1 >= 0 && !m->map[y - 1][x]) {
      if ((rand() % 100) < 20) {
        m->map[y - 1][x] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y - 1;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (y + 1 < MAP_Y && !m->map[y + 1][x]) {
      if ((rand() % 100) < 20) {
        m->map[y + 1][x] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y + 1;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    if (x + 1 < MAP_X && !m->map[y][x + 1]) {
      if ((rand() % 100) < 80) {
        m->map[y][x + 1] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x + 1;
        tail->y = y;
      } else if (!added_current) {
        added_current = 1;
        m->map[y][x] = i;
        tail->next = malloc(sizeof (*tail));
        tail = tail->next;
        tail->next = NULL;
        tail->x = x;
        tail->y = y;
      }
    }

    added_current = 0;
    tmp = head;
    head = head->next;
    free(tmp);
  }

  /*
  out = fopen("diffused.pgm", "w");
  fprintf(out, "P5\n%u %u\n255\n", MAP_X, MAP_Y);
  fwrite(&m->map, sizeof (m->map), 1, out);
  fclose(out);
  */
  
  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (y == 0 || y == MAP_Y - 1 ||
          x == 0 || x == MAP_X - 1) {
        mapxy(x, y) = border_type(m, x, y);
      }
    }
  }

  m->n = n;
  m->s = s;
  m->e = e;
  m->w = w;

  if (n != -1) {
    mapxy(n,         0        ) = ter_gate;
    mapxy(n,         1        ) = ter_gate;
  }
  if (s != -1) {
    mapxy(s,         MAP_Y - 1) = ter_gate;
    mapxy(s,         MAP_Y - 2) = ter_gate;
  }
  if (w != -1) {
    mapxy(0,         w        ) = ter_gate;
    mapxy(1,         w        ) = ter_gate;
  }
  if (e != -1) {
    mapxy(MAP_X - 1, e        ) = ter_gate;
    mapxy(MAP_X - 2, e        ) = ter_gate;
  }

  return 0;
}

static int place_boulders(map_t *m)
{
  int i;
  int x, y;

  for (i = 0; i < MIN_BOULDERS || rand() % 100 < BOULDER_PROB; i++) {
    y = rand() % (MAP_Y - 2) + 1;
    x = rand() % (MAP_X - 2) + 1;
    if (m->map[y][x] != ter_forest &&
        m->map[y][x] != ter_path   &&
        m->map[y][x] != ter_gate) {
      m->map[y][x] = ter_boulder;
    }
  }

  return 0;
}

static int place_trees(map_t *m)
{
  int i;
  int x, y;
  
  for (i = 0; i < MIN_TREES || rand() % 100 < TREE_PROB; i++) {
    y = rand() % (MAP_Y - 2) + 1;
    x = rand() % (MAP_X - 2) + 1;
    if (m->map[y][x] != ter_mountain &&
        m->map[y][x] != ter_path     &&
        m->map[y][x] != ter_water    &&
        m->map[y][x] != ter_gate) {
      m->map[y][x] = ter_tree;
    }
  }

  return 0;
}

// New map expects cur_idx to refer to the index to be generated.  If that
// map has already been generated then the only thing this does is set
// cur_map.
static int new_map()
{
  int d, p;
  int e, w, n, s;

  if (world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x]]) {
    world.cur_map = world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x]];
    return 0;
  }

  world.cur_map                                             =
    world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x]] =
    malloc(sizeof (*world.cur_map));

  smooth_height(world.cur_map);
  
  if (!world.cur_idx[dim_y]) {
    n = -1;
  } else if (world.world[world.cur_idx[dim_y] - 1][world.cur_idx[dim_x]]) {
    n = world.world[world.cur_idx[dim_y] - 1][world.cur_idx[dim_x]]->s;
  } else {
    n = 1 + rand() % (MAP_X - 2);
  }
  if (world.cur_idx[dim_y] == WORLD_SIZE - 1) {
    s = -1;
  } else if (world.world[world.cur_idx[dim_y] + 1][world.cur_idx[dim_x]]) {
    s = world.world[world.cur_idx[dim_y] + 1][world.cur_idx[dim_x]]->n;
  } else  {
    s = 1 + rand() % (MAP_X - 2);
  }
  if (!world.cur_idx[dim_x]) {
    w = -1;
  } else if (world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x] - 1]) {
    w = world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x] - 1]->e;
  } else {
    w = 1 + rand() % (MAP_Y - 2);
  }
  if (world.cur_idx[dim_x] == WORLD_SIZE - 1) {
    e = -1;
  } else if (world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x] + 1]) {
    e = world.world[world.cur_idx[dim_y]][world.cur_idx[dim_x] + 1]->w;
  } else {
    e = 1 + rand() % (MAP_Y - 2);
  }
  
  map_terrain(world.cur_map, n, s, e, w); // map terrain
     
  place_boulders(world.cur_map); // place boulders
  place_trees(world.cur_map); // place trees
  build_paths(world.cur_map); // build paths


  d = (abs(world.cur_idx[dim_x] - (WORLD_SIZE / 2)) +
       abs(world.cur_idx[dim_y] - (WORLD_SIZE / 2)));
  p = d > 200 ? 5 : (50 - ((45 * d) / 200));
  //  printf("d=%d, p=%d\n", d, p);
  if ((rand() % 100) < p || !d) {
    place_pokemart(world.cur_map);
  }
  if ((rand() % 100) < p || !d) {
    place_center(world.cur_map);
  }

  return 0;
}

//changed the map to just print update the trainers and terrain features
//into the global map 2d array, this array will remember this and print it out
static void print_map(trainers_t trainers[])
{
  int x, y;
  int default_reached = 0;

  printf("\n\n\n");

  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (world.pc.pos[dim_y] == y &&
          world.pc.pos[dim_x] == x) {
        map[y][x] = char_pc;
      } else {
        switch (world.cur_map->map[y][x]) {
        case ter_boulder:
          map[y][x] = (BOULDER_SYMBOL);
          break;
        case ter_mountain:
          map[y][x] = (MOUNTAIN_SYMBOL);
          break;
        case ter_tree:
          map[y][x] = (TREE_SYMBOL);
          break;
        case ter_forest:
          map[y][x] = (FOREST_SYMBOL);
          break;
        case ter_path:
          map[y][x] = (PATH_SYMBOL);
          break;
        case ter_gate:
          map[y][x] = (GATE_SYMBOL);
          break;
        case ter_mart:
          map[y][x] = (POKEMART_SYMBOL);
          break;
        case ter_center:
          map[y][x] = (POKEMON_CENTER_SYMBOL);
          break;
        case ter_grass:
          map[y][x] = (TALL_GRASS_SYMBOL);
          break;
        case ter_clearing:
          map[y][x] = (SHORT_GRASS_SYMBOL);
          break;
        case ter_water:
          map[y][x] = (WATER_SYMBOL);
          break;
        default:
          putchar(ERROR_SYMBOL);
          default_reached = 1;
          break;
        }
      }
    }
    putchar('\n');
  }

  for(int i = 0; i < numtrainers; i++) { // update the location of the trainers
      map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]] = trainers[i].trainers;
  }

  for(y = 0; y < MAP_Y; y++){// print map
    for(x = 0; x < MAP_X; x++){
        printf("%c", map[y][x]);
      }
    printf("\n");
  }

  if (default_reached) {
    fprintf(stderr, "Default reached in %s\n", __FUNCTION__);
  }
}

// The world is global because of its size, so init_world is parameterless
void init_world()
{
  world.cur_idx[dim_x] = world.cur_idx[dim_y] = WORLD_SIZE / 2;
  new_map();
}

void delete_world()
{
  int x, y;

  for (y = 0; y < WORLD_SIZE; y++) {
    for (x = 0; x < WORLD_SIZE; x++) {
      if (world.world[y][x]) {
        free(world.world[y][x]);
        world.world[y][x] = NULL;
      }
    }
  }
}

#define ter_cost(x, y, c) move_cost[c][m->map[y][x]] //terrain cost of moving

static int32_t hiker_cmp(const void *key, const void *with) {
  return (world.hiker_dist[((path_t *) key)->pos[dim_y]]
                          [((path_t *) key)->pos[dim_x]] -
          world.hiker_dist[((path_t *) with)->pos[dim_y]]
                          [((path_t *) with)->pos[dim_x]]);
}

static int32_t rival_cmp(const void *key, const void *with) {
  return (world.rival_dist[((path_t *) key)->pos[dim_y]]
                          [((path_t *) key)->pos[dim_x]] -
          world.rival_dist[((path_t *) with)->pos[dim_y]]
                          [((path_t *) with)->pos[dim_x]]);
}

void pathfind(map_t *m) //
{
  heap_t h;
  uint32_t x, y;
  static path_t p[MAP_Y][MAP_X], *c;
  static uint32_t initialized = 0;

  if (!initialized) {
    initialized = 1;
    for (y = 0; y < MAP_Y; y++) {
      for (x = 0; x < MAP_X; x++) {
        p[y][x].pos[dim_y] = y;
        p[y][x].pos[dim_x] = x;
      }
    }
  }

  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      world.hiker_dist[y][x] = world.rival_dist[y][x] = INT_MAX;
    }
  }
  world.hiker_dist[world.pc.pos[dim_y]][world.pc.pos[dim_x]] = 
    world.rival_dist[world.pc.pos[dim_y]][world.pc.pos[dim_x]] = 0;

  heap_init(&h, hiker_cmp, NULL);

  for (y = 1; y < MAP_Y - 1; y++) {
    for (x = 1; x < MAP_X - 1; x++) {
      if (ter_cost(x, y, char_hiker) != INT_MAX) {
        p[y][x].hn = heap_insert(&h, &p[y][x]);
      } else {
        p[y][x].hn = NULL;
      }
    }
  }

  while ((c = heap_remove_min(&h))) {
    c->hn = NULL;
    if ((p[c->pos[dim_y] - 1][c->pos[dim_x] - 1].hn) &&
        (world.hiker_dist[c->pos[dim_y] - 1][c->pos[dim_x] - 1] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y] - 1][c->pos[dim_x] - 1] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] - 1][c->pos[dim_x] - 1].hn);
    }
    if ((p[c->pos[dim_y] - 1][c->pos[dim_x]    ].hn) &&
        (world.hiker_dist[c->pos[dim_y] - 1][c->pos[dim_x]    ] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y] - 1][c->pos[dim_x]    ] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] - 1][c->pos[dim_x]    ].hn);
    }
    if ((p[c->pos[dim_y] - 1][c->pos[dim_x] + 1].hn) &&
        (world.hiker_dist[c->pos[dim_y] - 1][c->pos[dim_x] + 1] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y] - 1][c->pos[dim_x] + 1] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] - 1][c->pos[dim_x] + 1].hn);
    }
    if ((p[c->pos[dim_y]    ][c->pos[dim_x] - 1].hn) &&
        (world.hiker_dist[c->pos[dim_y]    ][c->pos[dim_x] - 1] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y]    ][c->pos[dim_x] - 1] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y]    ][c->pos[dim_x] - 1].hn);
    }
    if ((p[c->pos[dim_y]    ][c->pos[dim_x] + 1].hn) &&
        (world.hiker_dist[c->pos[dim_y]    ][c->pos[dim_x] + 1] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y]    ][c->pos[dim_x] + 1] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y]    ][c->pos[dim_x] + 1].hn);
    }
    if ((p[c->pos[dim_y] + 1][c->pos[dim_x] - 1].hn) &&
        (world.hiker_dist[c->pos[dim_y] + 1][c->pos[dim_x] - 1] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y] + 1][c->pos[dim_x] - 1] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] + 1][c->pos[dim_x] - 1].hn);
    }
    if ((p[c->pos[dim_y] + 1][c->pos[dim_x]    ].hn) &&
        (world.hiker_dist[c->pos[dim_y] + 1][c->pos[dim_x]    ] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y] + 1][c->pos[dim_x]    ] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] + 1][c->pos[dim_x]    ].hn);
    }
    if ((p[c->pos[dim_y] + 1][c->pos[dim_x] + 1].hn) &&
        (world.hiker_dist[c->pos[dim_y] + 1][c->pos[dim_x] + 1] >
         world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker))) {
      world.hiker_dist[c->pos[dim_y] + 1][c->pos[dim_x] + 1] =
        world.hiker_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_hiker);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] + 1][c->pos[dim_x] + 1].hn);
    }
  }
  heap_delete(&h);

  heap_init(&h, rival_cmp, NULL);

  for (y = 1; y < MAP_Y - 1; y++) {
    for (x = 1; x < MAP_X - 1; x++) {
      if (ter_cost(x, y, char_rival) != INT_MAX) {
        p[y][x].hn = heap_insert(&h, &p[y][x]);
      } else {
        p[y][x].hn = NULL;
      }
    }
  }

  while ((c = heap_remove_min(&h))) {
    c->hn = NULL;
    if ((p[c->pos[dim_y] - 1][c->pos[dim_x] - 1].hn) &&
        (world.rival_dist[c->pos[dim_y] - 1][c->pos[dim_x] - 1] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y] - 1][c->pos[dim_x] - 1] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] - 1][c->pos[dim_x] - 1].hn);
    }
    if ((p[c->pos[dim_y] - 1][c->pos[dim_x]    ].hn) &&
        (world.rival_dist[c->pos[dim_y] - 1][c->pos[dim_x]    ] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y] - 1][c->pos[dim_x]    ] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] - 1][c->pos[dim_x]    ].hn);
    }
    if ((p[c->pos[dim_y] - 1][c->pos[dim_x] + 1].hn) &&
        (world.rival_dist[c->pos[dim_y] - 1][c->pos[dim_x] + 1] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y] - 1][c->pos[dim_x] + 1] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] - 1][c->pos[dim_x] + 1].hn);
    }
    if ((p[c->pos[dim_y]    ][c->pos[dim_x] - 1].hn) &&
        (world.rival_dist[c->pos[dim_y]    ][c->pos[dim_x] - 1] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y]    ][c->pos[dim_x] - 1] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y]    ][c->pos[dim_x] - 1].hn);
    }
    if ((p[c->pos[dim_y]    ][c->pos[dim_x] + 1].hn) &&
        (world.rival_dist[c->pos[dim_y]    ][c->pos[dim_x] + 1] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y]    ][c->pos[dim_x] + 1] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y]    ][c->pos[dim_x] + 1].hn);
    }
    if ((p[c->pos[dim_y] + 1][c->pos[dim_x] - 1].hn) &&
        (world.rival_dist[c->pos[dim_y] + 1][c->pos[dim_x] - 1] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y] + 1][c->pos[dim_x] - 1] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] + 1][c->pos[dim_x] - 1].hn);
    }
    if ((p[c->pos[dim_y] + 1][c->pos[dim_x]    ].hn) &&
        (world.rival_dist[c->pos[dim_y] + 1][c->pos[dim_x]    ] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y] + 1][c->pos[dim_x]    ] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] + 1][c->pos[dim_x]    ].hn);
    }
    if ((p[c->pos[dim_y] + 1][c->pos[dim_x] + 1].hn) &&
        (world.rival_dist[c->pos[dim_y] + 1][c->pos[dim_x] + 1] >
         world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
         ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival))) {
      world.rival_dist[c->pos[dim_y] + 1][c->pos[dim_x] + 1] =
        world.rival_dist[c->pos[dim_y]][c->pos[dim_x]] +
        ter_cost(c->pos[dim_x], c->pos[dim_y], char_rival);
      heap_decrease_key_no_replace(&h,
                                   p[c->pos[dim_y] + 1][c->pos[dim_x] + 1].hn);
    }
  }
  heap_delete(&h);
}

void init_pc() // initialize the player character
{
  int x, y;

  do {
    x = rand() % (MAP_X - 2) + 1;
    y = rand() % (MAP_Y - 2) + 1;
  } while (world.cur_map->map[y][x] != ter_path);

  world.pc.pos[dim_x] = x;
  world.pc.pos[dim_y] = y;
}

void print_hiker_dist()
{
  int x, y;

  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (world.hiker_dist[y][x] == INT_MAX) {
        printf("   ");
      } else {
        printf(" %02d", world.hiker_dist[y][x] % 100);
      }
    }
    printf("\n");
  }
}

void print_rival_dist()
{
  int x, y;

  for (y = 0; y < MAP_Y; y++) {
    for (x = 0; x < MAP_X; x++) {
      if (world.rival_dist[y][x] == INT_MAX || world.rival_dist[y][x] < 0) {
        printf("   ");
      } else {
        printf(" %02d", world.rival_dist[y][x] % 100);
      }
    }
    printf("\n");
  }
}

void reset_hiker_cost(trainers_t trainers[], int i)
{
   terrain_type_t current_terrain = world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]];
    switch(current_terrain) {
        case ter_forest:
        case ter_mountain:
        case ter_grass:
            trainers[i].cost += 15;
            break;
        default:
            trainers[i].cost += 10;
            break;
    }
}

void reset_trainer_cost(trainers_t trainers[], int i)
{
    terrain_type_t current_terrain = world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]];
    trainers[i].cost += (current_terrain == ter_grass) ? 20 : 10;
    
}

char blocked_characters[] = {'h', 'r', 'p', 'w', 's', 'e'}; // characters that can't be walked on


void move_hiker(trainers_t trainers[], int i){
   int j;
    int new_move = 0;
    int currentY, currentX, newY, newX;
    int new_X, new_Y;
    
    int min = world.rival_dist[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]];


    // Check if character is in the list of blocked characters
    int is_blocked_char(char c) {
        for (int k = 0; k < sizeof(blocked_characters); k++) {
            if (c == blocked_characters[k]) return 1;
        }
        return 0;
    }

    int new_location[8][2] = {
            {-1, -1},
            {-1, 0},
            {-1, 1},
            {0, -1},
            {0, 1},
            {1, -1},
            {1, 0},
            {1, 1}
    };

    for(j = 0; j < 8; j++) {
    currentY = trainers[i].pos[dim_y];
    currentX = trainers[i].pos[dim_x];
    newY = currentY + new_location[j][0];
    newX = currentX + new_location[j][1];

        // Check if the new location is within map bounds 
        if(newY < 0 || newY >= MAP_Y || newX < 0 || newX >= MAP_X) {
            continue;
        }

        int current_dist = world.rival_dist[newY][newX];

        if(current_dist < min) {
            min = current_dist;
            new_move = j;
            
            // If a distance of 0 is the minimum possible and the best, then break once you've found it
            if(current_dist == 0) {
                break;
            }

        }
    }

    new_X = trainers[i].pos[dim_x] + new_location[new_move][1];
    new_Y = trainers[i].pos[dim_y] + new_location[new_move][0];

    if (((new_X == world.pc.pos[dim_x]) && (new_Y == world.pc.pos[dim_y]))|| (is_blocked_char(map[new_Y][new_X]))) {
        // do nothing

    } else {
        trainers[i].pos[dim_x] = new_X;
        trainers[i].pos[dim_y] = new_Y;
    } 
}

void move_rival(trainers_t trainers[], int i){
    int j;
    int new_move = 0;
    int currentY, currentX, newY, newX;
    int new_X, new_Y;
    
    int min = world.rival_dist[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]];

    // Check if character is in the list of blocked characters
    int is_blocked_char(char c) {
        for (int k = 0; k < sizeof(blocked_characters); k++) {
            if (c == blocked_characters[k]) return 1;
        }
        return 0;
    }

    int new_location[8][2] = {
            {-1, -1},
            {-1, 0},
            {-1, 1},
            {0, -1},
            {0, 1},
            {1, -1},
            {1, 0},
            {1, 1}
    };

    for(j = 0; j < 8; j++) {
    currentY = trainers[i].pos[dim_y];
    currentX = trainers[i].pos[dim_x];
    newY = currentY + new_location[j][0];
    newX = currentX + new_location[j][1];

        // Check if the new location is within map bounds 
        if(newY < 0 || newY >= MAP_Y || newX < 0 || newX >= MAP_X) {
            continue;
        }

        int current_dist = world.rival_dist[newY][newX];

        if(current_dist < min) {
            min = current_dist;
            new_move = j;
            
            // If a distance of 0 is the minimum possible and the best, then break once you've found it
            if(current_dist == 0) {
                break;
            }

        }
    }

    new_X = trainers[i].pos[dim_x] + new_location[new_move][1];
    new_Y = trainers[i].pos[dim_y] + new_location[new_move][0];

    if (((new_X == world.pc.pos[dim_x]) && (new_Y == world.pc.pos[dim_y]))|| (is_blocked_char(map[new_Y][new_X]))) {
        // do nothing

    } else {
        trainers[i].pos[dim_x] = new_X;
        trainers[i].pos[dim_y] = new_Y;
    }

}


void move_pacer(trainers_t trainers[], int i){

  int checking_ter(int x, int y){
    if(world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_forest &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_mountain &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_boulder &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_tree &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_mart &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_center &&
         map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'h' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'r' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'p' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'w' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 's' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'n'){
          return 1;
         }
    if(world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_forest &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_mountain &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_boulder &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_tree &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_mart &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_center &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'h' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'r' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'p' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'w' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 's' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'n'){
          return 1;
        }
         else{
          return 0;
         }  
  }
    if(trainers[i].dir == 1) {
        if(checking_ter(-1,0)) {
            if(trainers[i].pos[dim_y] - 1 != 0) {
                trainers[i].pos[dim_y] -= 1;
            }
            else {
                trainers[i].dir = 3;
            }
        }
        else {
            trainers[i].dir = 3;
        }
    }
    else if(trainers[i].dir == 2) {
        if(checking_ter(0,-1)) {
            if(trainers[i].pos[dim_x] - 1 != 0) {
                trainers[i].pos[dim_x] -= 1;
            }
            else {
                trainers[i].dir = 4;
            }
        }
        else {
            trainers[i].dir = 4;
        }
    }
    else if(trainers[i].dir == 3) {
        if(checking_ter(1,0)) {
            if(trainers[i].pos[dim_y] + 1 != MAP_Y - 1) {
                trainers[i].pos[dim_y] += 1;
            }
            else {
                trainers[i].dir = 1;
            }
        }
        else {
            trainers[i].dir = 1;
        }
    }
    else if(trainers[i].dir == 4) {
        if(checking_ter(0,1)) {
            if(trainers[i].pos[dim_x] + 1 != MAP_X - 1) {
                trainers[i].pos[dim_x] += 1;
            }
            else {
                trainers[i].dir = 2;
            }
        }
        else {
            trainers[i].dir = 2;
        }
    }

}

void move_wanderer(trainers_t trainers[], int i)
{
    terrain_type_t terrain = world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]];

    if(trainers[i].dir == 1) {
        if(world.cur_map->map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] == terrain &&
        map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] != 'h' &&
        map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] != 'r' &&
        map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] != 'p' &&
        map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] != 'w' &&
        map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] != 's' &&
        map[trainers[i].pos[dim_y] - 1][trainers[i].pos[dim_x]] != 'n') {
            if(trainers[i].pos[dim_y] - 1 != 0) {
                trainers[i].pos[dim_y] -= 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
    else if(trainers[i].dir == 2) {
        if(world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] == terrain &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] != 'h' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] != 'r' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] != 'p' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] != 'w' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] != 's' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] - 1] != 'n') {
            if(trainers[i].pos[dim_x] - 1 != 0) {
                trainers[i].pos[dim_x] -= 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
    else if(trainers[i].dir == 3) {
        if(world.cur_map->map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] == terrain &&
        map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] != 'h' &&
        map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] != 'r' &&
        map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] != 'p' &&
        map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] != 'w' &&
        map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] != 's' &&
        map[trainers[i].pos[dim_y] + 1][trainers[i].pos[dim_x]] != 'n') {
            if(trainers[i].pos[dim_y] + 1 != 0) {
                trainers[i].pos[dim_y] += 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
    else if(trainers[i].dir == 4) {
        if(world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] == terrain &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'h' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'r' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'p' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'w' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 's' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'n') {
            if(trainers[i].pos[dim_x] + 1 != 0) {
                trainers[i].pos[dim_x] += 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
}

void move_explorer(trainers_t trainers[], int i){

    int checking_ter(int x, int y){
    if(world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_forest &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_mountain &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_boulder &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_tree &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_mart &&
         world.cur_map->map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != ter_center &&
         map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'h' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'r' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'p' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'w' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 's' &&
        map[trainers[i].pos[dim_y] + y][trainers[i].pos[dim_x]] != 'n'){
          return 1;
         }
    if(world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_forest &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_mountain &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_boulder &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_tree &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_mart &&
        world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + x] != ter_center &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'h' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'r' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'p' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'w' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 's' &&
        map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x] + 1] != 'n'){
          return 1;
        }
         else{
          return 0;
         }  
  }

    if(trainers[i].dir == 1) {
        if(checking_ter(0,-1)) {
            if(trainers[i].pos[dim_y] - 1 != 0) {
                trainers[i].pos[dim_y] -= 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
    else if(trainers[i].dir == 2) {
        if(checking_ter(-1,0)) {
            if(trainers[i].pos[dim_x] - 1 != 0) {
                trainers[i].pos[dim_x] -= 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
    else if(trainers[i].dir == 3) {
        if(checking_ter(0,1)) {
            if(trainers[i].pos[dim_y] + 1 != 0) {
                trainers[i].pos[dim_y] += 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
    else if(trainers[i].dir == 4) {
        if(checking_ter(1,0)) {
            if(trainers[i].pos[dim_x] + 1 != 0) {
                trainers[i].pos[dim_x] += 1;
            }
            else {
                trainers[i].dir = (rand() % 4) + 1;
            }
        }
        else {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }
}

void move_sentry(trainers_t trainers[], int i){
//do nothing
}



int get_cost_for_terrain(terrain_type_t terrain, char trainer_type) {
    if(trainer_type == 'h') {
        if(terrain == ter_forest || terrain == ter_mountain || terrain == ter_grass) {
            return 15;
        }
        return 10;
    } else {
        if(terrain == ter_grass) {
            return 20;
        }
        return 10;
    }
}

void set_trainer_cost(trainers_t trainers[] )
{
    int i;
    terrain_type_t terrain;

    for(i = 0; i < numtrainers; i++) {
        terrain = world.cur_map->map[trainers[i].pos[dim_y]][trainers[i].pos[dim_x]];
        trainers[i].cost = get_cost_for_terrain(terrain, trainers[i].trainers);
    }
}




void place_trainers(trainers_t trainers[]){

  int i, x, y, num_hikers, num_rivals, rand_trainer;
  terrain_type_t terrain;

  const int MAX_HIKERS = 1;
  const int MAX_RIVALS = 1;

  num_hikers = num_rivals = 0;

  trainers[0].pos[dim_x] = world.pc.pos[dim_x];
  trainers[0].pos[dim_y] = world.pc.pos[dim_y];
  trainers[0].place = 0;
  trainers[0].trainers = '@';

  i = 1;

  while(i < numtrainers) {
      x = rand() % (MAP_X - 2) + 1;
      y = rand() % (MAP_Y - 2) + 1;

      terrain = world.cur_map->map[y][x];



      void set_trainer_properties(char type){
        trainers[i].pos[dim_x] = x;
        trainers[i].pos[dim_y] = y;
        trainers[i].place = i;
        trainers[i].trainers = type;
        i++;
    }

      if(terrain != ter_boulder && terrain != ter_tree && terrain != ter_center && terrain != ter_mart && 
        x != trainers[0].pos[dim_x] && y != trainers[0].pos[dim_y]) {
          
          if(num_hikers < MAX_HIKERS) {
              set_trainer_properties('h');
              num_hikers++;

          } else if(num_rivals < MAX_RIVALS && terrain != ter_mountain && terrain != ter_forest) {
              set_trainer_properties('r');
              num_rivals++;

          } else if(terrain != ter_mountain && terrain != ter_forest) {
              char trainer_types[] = {'r', 'p', 'w', 's', 'h', 'e'};
              rand_trainer = rand() % 6;
              set_trainer_properties(trainer_types[rand_trainer]);

          }
      }
  }
}



int main(int argc, char *argv[])
{
  struct timeval tv;
  uint32_t seed;
  int i;
  heap_t h;

numtrainers = 10;
    if(argc > 2 && strcmp(argv[1], "--numtrainers") == 0) {
            numtrainers = atoi(argv[2]);
    }

    numtrainers++;

  gettimeofday(&tv, NULL);
  seed = (tv.tv_usec ^ (tv.tv_sec << 20)) & 0xffffffff;

  printf("Using seed: %u\n", seed);
  srand(seed);

  init_world();
  init_pc();
  pathfind(world.cur_map);

    trainers_t trainers[numtrainers], *t_pointer;
    place_trainers(trainers);
    set_trainer_cost(trainers);

    // Initialize direction for certain trainers
    for(i = 0; i < numtrainers; i++) {
        if(trainers[i].trainers == 'p' || trainers[i].trainers == 'w' || trainers[i].trainers == 'n' || trainers[i].trainers == 's' || trainers[i].trainers == 'e') {
            trainers[i].dir = (rand() % 4) + 1;
        }
    }

    print_map(trainers);

    heap_init(&h, compareTrainers, NULL);
    for(i = 0; i < numtrainers; i++) {
        heap_insert(&h, &trainers[i]);
    }

    while (1) {
    t_pointer = heap_remove_min(&h);
    if (!t_pointer) {
        // Handle this error situation
        printf("Error: t_pointer is NULL\n");
        exit(1);
    }


    switch (t_pointer->trainers) {
        case 'p':
            move_pacer(trainers, t_pointer->place);
            reset_hiker_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            break;
        case 's':
            move_sentry(trainers, t_pointer->place);
            reset_hiker_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            break;
        case 'e':
            move_explorer(trainers, t_pointer->place);
            reset_hiker_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            break;
        case 'w':
            move_wanderer(trainers, t_pointer->place);
            reset_hiker_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            break;
        case 'r':
            move_rival(trainers, t_pointer->place);
            reset_hiker_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            break;
        case 'h':
            move_hiker(trainers, t_pointer->place);
            reset_hiker_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            break;
        case '@':
            reset_trainer_cost(trainers, t_pointer->place);
            heap_insert(&h, &trainers[t_pointer->place]);
            print_map(trainers);
            usleep(100000);
            break;
        default:
            // Handle unexpected trainer types
            printf("Error: Unknown trainer type\n");
            exit(1);
      }
    }

    heap_delete(&h);
  return 0;

}