// GHOST_H
#ifndef GHOST_H
#define GHOST_H

#include <cstdlib> 
#include <cstdio>
#include <vector>
#include <cmath>
#include <set>
#include "pacman.h"



class Ghost {
    // Class declaration
    
     public:
        Ghost() : x(0), y(0), id(0) {} // Default constructor with member initializer list

        int x, y, id;

        int getX(){
            return x;
        }

        int getY(){
            return y;
        }
        int getID(){
            return id;
        }
    };





#endif // GHOST_H