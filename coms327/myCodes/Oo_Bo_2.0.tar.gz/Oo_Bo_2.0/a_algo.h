#ifndef A_ALGO
#define A_ALGO

#include <iostream>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <utility> // Add this line to include the utility header
#include "hades.h"
#include "pacman.h"

#define ROWS 23
#define COLS 21


// Creating a shortcut for int, int pair type
typedef std::pair<int, int> Pair;


// Creating a shortcut for pair<int, pair<int, int>> type
typedef std::pair<double, std::pair<int, int>> pPair;



// A Utility Function to check whether given cell (ROWS, COLS)
// is a valid cell or not.
bool isValid(int row, int col);

// A Utility Function to check whether the given cell is
// blocked or not
bool isUnBlocked(int grid[][COLS], int row, int col);

// A Utility Function to check whether destination cell has
// been reached or not
bool isDestination(int row, int col, Pair dest);

// A Utility Function to calculate the 'h' heuristics.
double calculateHValue(int row, int col, Pair dest);


void aStarSearch(int grid[][COLS], Pair src, Pair dest);




#endif