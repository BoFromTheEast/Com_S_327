#ifndef HADES
#define HADES    


#include "ghost.h"
#include "a_algo.h"  // Include a_algo.h last

// All the elements to be used 
// Declared here 

#define PACMAN  'C' 
#define WALL    '|' 
#define FOOD    '.' 
#define SPACE   ' '
#define DEMON   'X'
#define ROWS     23
#define COLS     21

using namespace std;


extern int lives;
extern int ghostCount;
extern int score;
extern int foods;
extern Pacman newPacman;
extern Ghost ghost1;
extern Ghost ghost2;
extern Ghost ghost3;

struct Point {
    int x, y;
    Point(int x, int y) : x(x), y(y) {}

};

extern char newMap[ROWS][COLS];
 
extern int charMap[ROWS][COLS];



#endif  