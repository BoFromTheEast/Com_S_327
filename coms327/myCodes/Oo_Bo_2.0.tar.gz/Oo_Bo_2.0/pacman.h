// Pacman.h
#ifndef PACMAN_H
#define PACMAN_H


#include <cstdlib> 
#include <cstdio>
#include <vector>

//directions
enum Direction {
    DIRECTION_RIGHT,
    DIRECTION_UP,
    DIRECTION_LEFT,
    DIRECTION_DOWN
};


class Pacman {
    public:
        Pacman() : x(0), y(0) {} // Default constructor with member initializer list

        int x;
        int y;

        int getX(){
            return x;
        }

        int getY(){
            return y;
        }

};
#endif // PACMAN_H