// Pacman Game in CPP language 

#include <cstdlib> 
#include <cstdio>
#include <ncurses.h>
#include <bits/stdc++.h>
#include <stdbool.h>
#include <vector>
#include <vector>
#include <cmath>
#include <cstdio>
#include <cmath>
#include <set>

#include "hades.h"
#include "pacman.h"
#include "ghost.h"
#include "a_algo.h"  

using namespace std;
bool playerMoved = false;
int lives =      3;
int ghostCount = 3;
int score =      0;
int foods =      50;
Pacman newPacman;
Ghost ghost1;
Ghost ghost2;
Ghost ghost3;
bool gameOver = false;

int ghostDirection = DIRECTION_RIGHT;



char newMap[ROWS][COLS];
 
int charMap[ROWS][COLS] = {         {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                                    {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                                    {1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1},
                                    {1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1},
                                    {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                                    {1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1},
                                    {1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1},
                                    {1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1},
                                    {0, 0, 0, 0, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 0, 0, 0, 0},
                                    {1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1},
                                    {1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1},
                                    {1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1},
                                    {0, 0, 0, 0, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 0, 0, 0, 0},
                                    {0, 0, 0, 0, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 0, 0, 0, 0},
                                    {1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1},
                                    {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                                    {1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1},
                                    {1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1},
                                    {1, 1, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 1, 1},
                                    {1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1},
                                    {1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1},
                                    {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                                    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
                };

void createMap() {
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j) {
            switch(charMap[i][j]) { // Assuming charMap is source array
                case 1:
                    newMap[i][j] = WALL;
                    break;
                case 2:
                    if(newMap[i][j] != PACMAN){
                        newMap[i][j] = FOOD;
                    }
                    break;
                case 'C': 
                    newMap[i][j] = PACMAN;
                    break;
                case 0:
                    newMap[i][j] = SPACE;
                    break;
                case 'X':
                    newMap[i][j] = DEMON;
                    break;
            }
        }
    }
}



void draw() {
    clear(); // Clear the screen
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j) {


            switch(newMap[i][j]){
                case WALL:
                case 1:
                    attron(COLOR_PAIR(COLOR_RED));
                    mvaddch(i+3,j+3,WALL);
                    attroff(COLOR_PAIR(COLOR_RED));
                    break;
                case FOOD:
                case 2:
                    attron(COLOR_PAIR(COLOR_GREEN));
                    mvaddch(i+3,j+3,FOOD);
                    attroff(COLOR_PAIR(COLOR_GREEN));
                    break;
                case PACMAN:
                    attron(COLOR_PAIR(COLOR_YELLOW));
                    mvaddch(i+3,j+3,PACMAN);
                    attroff(COLOR_PAIR(COLOR_YELLOW));
                    break;
                case DEMON:
                    attron(COLOR_PAIR(COLOR_BLUE));
                    mvaddch(i+3,j+3,DEMON);
                    attroff(COLOR_PAIR(COLOR_BLUE));
                    break;
                case 0:
                    mvaddch(i+3,j+3, SPACE);
                    break;
                default:
                    mvaddch(i+3, j+3, newMap[i][j]); // a placeholder character if charnewMap[i][j] is not valid
            }
        }
    }

        mvprintw(28, 0, "PACMAN POSITION: Y:%d X:%d", newPacman.getY(), newPacman.getX());
        mvprintw(29, 0, "GHOST POSITION: Y:%d X:%d", ghost1.getY(), ghost1.getX());
        mvprintw(30, 0, "GHOST POSITION: Y:%d X:%d", ghost2.getY(), ghost2.getX());
        mvprintw(31, 0, "GHOST POSITION: Y:%d X:%d", ghost3.getY(), ghost3.getX());
        mvprintw(32, 0, "FOODS LEFT TO EAT: %d", foods);
        mvprintw(33, 0, "SCORE: %d", score);
        refresh(); // Refresh to show changes
}

void moveGhost(Ghost &ghost) {
    // Define an array of possible directions
    int directions[] = {DIRECTION_UP, DIRECTION_DOWN, DIRECTION_LEFT, DIRECTION_RIGHT};

    // Shuffle the directions randomly
    for (int i = 3; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = directions[i];
        directions[i] = directions[j];
        directions[j] = temp;
    }

    // Try each direction in the shuffled order
    for (int i = 0; i < 4; i++) {
        int newX = ghost.x;
        int newY = ghost.y;

        // Update newX and newY based on the current direction
        if (directions[i] == DIRECTION_UP) {
            newY--;
        } else if (directions[i] == DIRECTION_DOWN) {
            newY++;
        } else if (directions[i] == DIRECTION_LEFT) {
            newX--;
        } else if (directions[i] == DIRECTION_RIGHT) {
            newX++;
        }

        // Check if the new position is valid (not a wall or out of bounds)
        if (isValid(newX, newY) && newMap[newY][newX] != WALL && newMap[newY][newX] != 1) {
            // Clear the previous position of the ghost
            newMap[ghost.y][ghost.x] = FOOD;

            // Update the ghost's position
            ghost.x = newX;
            ghost.y = newY;

            // Update the map with the ghost's new position
            newMap[newY][newX] = DEMON;

            // Exit the loop as the ghost has successfully moved
            break;
        }
    }

    // Control the speed of the ghost's movement by adjusting the usleep value
    usleep(25000); // Sleep for 50 milliseconds (adjust as needed)
}





void createPacman(){
    int midrow = ROWS / 2;
    int midcol = COLS / 2;
    
    if (newMap[midrow][midcol] != WALL && newMap[midrow][midcol] != 1) {
        newPacman.x = midcol;
        newPacman.y = midrow;
        newMap[midrow][midcol] = PACMAN;
    }
}



void createGhost() {
    int ghostPosX = 1; // Starting X position for the first ghost
    int ghostPosY = 1; // Starting Y position for the first ghost

    if (newMap[ghostPosY][ghostPosX] != WALL && newMap[ghostPosY][ghostPosX] != 1) {
        ghost1.x = ghostPosX;
        ghost1.y = ghostPosY;
        newMap[ghostPosY][ghostPosX] = DEMON;
    } else {
        // Handle the case where the newMap position is a wall
    }

    if (newMap[ghostPosY+1][ghostPosX] != WALL && newMap[ghostPosY+1][ghostPosX] != 1) {
        ghost2.x = ghostPosX;
        ghost2.y = ghostPosY+1;
        newMap[ghostPosY+1][ghostPosX] = DEMON;
    } else {
        // Handle the case where the newMap position is a wall

    }

    if (newMap[ghostPosY][ghostPosX+1] != WALL && newMap[ghostPosY][ghostPosX+1] != 1) {
        ghost3.x = ghostPosX+1;
        ghost3.y = ghostPosY;
        newMap[ghostPosY][ghostPosX+1] = DEMON;
    } else {
        // Handle the case where the newMap position is a wall
    }
}

// void pathfinding(){

//         // Source is the left-most bottom-most corner
//         Pair src = make_pair(ghost1.x, ghost1.y);
//         // Destination is the left-most top-most corner
//         Pair dest = make_pair(newPacman.x, newPacman.y);
//         aStarSearch(charMap, src, dest); // Pass the 2D grid array 'charMap' as the first argument
        
// }   

    


void movePacman(int dy, int dx) {
    int newMoveX = newPacman.x + dx;
    int newMoveY = newPacman.y + dy;
    int oldPosX = newPacman.x;
    int oldPosY = newPacman.y;

    // Check if the new position is a valid move (not a wall or out of bounds)
    if (newMap[newMoveY][newMoveX] != WALL && newMap[newMoveY][newMoveX] != 1) {
        // Check the neighboring cells for ghosts
        for (int yOffset = -1; yOffset <= 1; yOffset++) {
            for (int xOffset = -1; xOffset <= 1; xOffset++) {
                int neighborY = newMoveY + yOffset;
                int neighborX = newMoveX + xOffset;

                // Check if the neighboring cell contains a ghost
                if (newMap[neighborY][neighborX] == DEMON) {
                    gameOver = true; // Game over when pacman touches a ghost
                    cout << "Game Over! Your Score: " << score << endl;;
                    gameOver = true;
                }
            }
        }

        newMap[oldPosY][oldPosX] = SPACE; // Set the old position to empty or dot
        foods--;
        score++;
        newMap[newMoveY][newMoveX] = PACMAN;
        newPacman.x = newMoveX;
        newPacman.y = newMoveY;
        playerMoved = true; // Set playerMoved to true when the player makes a valid move
    }
}










void gameLoop() {
    char ch;
    initscr(); // Start ncurses mode
    noecho(); // Don't echo input characters
    cbreak(); // Disable line buffering, take input chars one at a time
    keypad(stdscr, TRUE); // Enable keyboard mapping
    nodelay(stdscr, TRUE); // Make getch non-blocking
    curs_set(0); // Hide the cursor
    start_color();
    init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
    init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);
    init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
    createMap();
    createPacman();
    createGhost();

     while (gameOver == false) {
        ch = getch();
        switch (ch) {
            case 'w':
                movePacman(-1, 0); // Move up
                break;
            case 's':
                movePacman(1, 0); // Move down
                break;
            case 'a':
                movePacman(0, -1); // Move left
                break;
            case 'd':
                movePacman(0, 1); // Move right
                break;
            case 'Q':
            case 'q':
            gameOver = true;
                cout << "Game Over! Your Score: " << score << endl;;;
                getch(); // Wait for key press
                endwin(); // End ncurses mode
                return;
        } 
        
        if( score >= 50){
            cout << "Game Over! You Won! Your Score: " << score << endl;
            gameOver = true;
        }
        draw(); // Moved outside the switch statement
        moveGhost(ghost1);
        moveGhost(ghost2);
        moveGhost(ghost3);

        usleep(50000); // Control refresh rate (adjust value as needed)
        refresh(); // Refresh to show changes

    }
}



// Main Function 
int main() 
{ 

	gameLoop();

	// // Source is the left-most bottom-most corner
    //     Pair src = make_pair(ghost1.x, ghost1.y);
    //     // Destination is the left-most top-most corner
    //     Pair dest = make_pair(newPacman.x, newPacman.y);
    //     aStarSearch(charMap, src, dest); // Pass the 2D grid array 'charMap' as the first argument
    
    endwin(); // Make sure to end the ncurses session


	return 0; 
}
