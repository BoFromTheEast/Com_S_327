#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


// /* This is to declare the world struct
// */
// struct world{
//  char world[401][401];
// };

/*
The dimension is to be 80 x 24 but the 3 of the 24 is to be used for game message while the 24 -3 = 21 is the actual length for the map;
*/
struct map{
    char grid[24][80]; // 2d array of the map
};

/* This is to declare the characters variables
*/
struct characters{
    char tree, grass, clearing,roads, pokemonCenter, pokeMart,boulders;
};

/* This is to initilize the characters in the Character struct
*/
struct characters defaultChar = {
    .tree = '^',
    .boulders = '%',
    .clearing = '.',
    .roads = '#',
    .pokeMart = 'M',
    .pokemonCenter = 'C',
    .grass = ':'
};

/* A struct to store the coordinates of the gates
*/
typedef struct {
    int leftGate;
    int rightGate;
    int northGate;
    int southGate;
}gateCoordinates;


/*
A map border created as soon as the map is to be generated 
*/
void map_border(struct map *border){
    int rows, columns; // the rows and columns of the map
    /*
    first three rows are supposed to be left empty
    */
    for(rows = 0; rows < 3; rows++){
        for(columns = 0; columns < 80; columns++){
            border->grid[rows][columns] = ' ';
        }
    }
   /*
    This is iterating through the map by going through each row and each column of the rows
    and checking if it is the first row or not to create a border
    and it leaves empty space if not first/last rows and columns
    */
    for(rows = 3; rows < 24; rows++){
        for(columns = 0; columns < 80; columns++){
            if(rows == 3 || rows == 23){
                border->grid[rows][columns] = '%';
            }
            else if(columns == 0 || columns == 79){
                border->grid[rows][columns] = '%';
            
            }
            else{
                border->grid[rows][columns] = '.';
            }
        }
    }
}

void objectPlacing(struct map *mapBorder, struct characters *terrainChar, char object, int size){
     int x = 0,y = 0;
        do {
        x = (rand() % (78 - size)) + 1;
        y = (rand() % (20 - size)) + 4;
        } while (mapBorder->grid[y][x] != terrainChar->clearing);

    for(int i = 0; i < size; ++i) {
        for(int j = 0; j < size; ++j) {
            mapBorder->grid[y + i][x + j] = object;
        }
    }
}

/* the left and right road
*/
void leftrightRoad(struct map *mapBorder, struct characters *terrainChar, char object,gateCoordinates *gateInfo) {
    int yRows,randomAmount;
    /* Got to initialize the variables to 0 to avoid garbage values
        Got to keep VALGRIND happy
    */
    randomAmount = 0;
    yRows = 0;
    yRows = (rand() % 20) + 4;  // Random row starting at 4 to leave the first 3 rows empty
    gateInfo->leftGate = yRows;

    // Horizontal road with occasional turns
for (int i = 0; i < 80; i++) {
    // Randomly decide if this section of the road will turn up or down
    int turn = rand() % 10;  // 10% chance to turn
    if (turn == 0) {
        randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
        yRows += randomAmount;  // Move the road up or down
        if (yRows < 4) yRows = 4;  // Don't go above the top boundary
        if (yRows > 21) yRows = 21;  // Don't go below the bottom boundary
    }
    // Place the road section
    if (yRows >= 0 && yRows < 23) {
            if (mapBorder->grid[yRows][i] != terrainChar->pokeMart && mapBorder->grid[yRows][i] != terrainChar->pokemonCenter) {
                mapBorder->grid[yRows][i] = object;
                gateInfo->rightGate = yRows;
            }
            else {
                mapBorder->grid[yRows+1][i] = object;
                gateInfo->rightGate = yRows+1;
            }
        }
    }
}
/* The up and down road of the map
*/
void updownRoad(struct map *mapBorder, struct characters *terrainChar, char object, gateCoordinates *gateInfo){
    int xRows, randomAmount;
    /* Got to initialize the variables to 0 to avoid garbage values
        Got to keep VALGRIND happy
    */
    randomAmount = 0;
    xRows = 0;
    xRows = (rand() % 78) + 1;  // Random column
    gateInfo->northGate = xRows;

    //Vertical road
    for (int i = 3; i < 24; i++) {  // Starting at 4 to leave the first 3 rows empty
        // Randomly decide if this section of the road will turn up or down
    int turn = rand() % 10;  // 10% chance to turn
    if (turn == 0) {
        randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
        xRows += randomAmount;  // Move the road up or down
        if (xRows < 0) xRows = 0;  // Don't go above the top boundary
        if (xRows > 79) xRows = 79;  // Don't go below the bottom boundary
        }
        // Place the road section
        if (xRows >= 0 && xRows < 79) {
            if(mapBorder->grid[i-1][xRows] != terrainChar->pokeMart && mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
            mapBorder->grid[i][xRows+randomAmount] = object;
            gateInfo->southGate = xRows+randomAmount;
            }else if(mapBorder->grid[i+1][xRows+1] == terrainChar->pokeMart || mapBorder->grid[i+1][xRows+1] == terrainChar->pokemonCenter){ 
                mapBorder->grid[i][xRows+2] = object;
                gateInfo->southGate = xRows;
            }
        }
    }
}

void connectGates(struct map *mapBorder, struct characters *terrainChar, char object, gateCoordinates *gateInfo, char direction){
    int randomAmount = 0;
    // connect the north gate to the new south gate
    if(direction == 'n'){
        leftrightRoad(mapBorder, terrainChar, object, gateInfo);
        int xRows = gateInfo->northGate; // Initialize the row to start from gateInfo->upGate
        for (int i = 23; i >= 4; i--) {  // Counting from bottom to top
            int turn = rand() % 10;  // 10% chance to turn
            if (turn == 0) {
                randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1
                xRows += randomAmount;
                if (xRows < 0) xRows = 0;  // Top boundary
                if (xRows > 79) xRows = 79;  // Bottom boundary
            }
            
            // Place the road section
            if (xRows >= 0 && xRows < 80) {
                if(mapBorder->grid[i+1][xRows] != terrainChar->pokeMart && mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
                    mapBorder->grid[i][xRows+randomAmount] = object;
                    gateInfo->southGate = xRows + randomAmount;
                } else if (mapBorder->grid[i-1][xRows-1] == terrainChar->pokeMart || mapBorder->grid[i-1][xRows-1] == terrainChar->pokemonCenter) {
                    mapBorder->grid[i][xRows-2] = object;
                    gateInfo->southGate = xRows;
                }
            }
        }
    }
    // connect the south gate to the new north gate
    if(direction == 's'){
        int xRows = gateInfo->southGate; // Initialize the row to start from gateInfo->leftGate
        leftrightRoad(mapBorder, terrainChar, object, gateInfo);
        for (int i = 3; i < 24; i++) {
        int turn = rand() % 10;  // 10% chance to turn
        if (turn == 0) {
            randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1
            xRows += randomAmount;
            if (xRows < 0) xRows = 0;  // Top boundary
            if (xRows > 79) xRows = 79;  // Bottom boundary
        }

        if (xRows >= 0 && xRows < 80) {
            if(mapBorder->grid[i-1][xRows] != terrainChar->pokeMart && mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
                mapBorder->grid[i][xRows+randomAmount] = object;
                gateInfo->southGate = xRows + randomAmount;
            } else if (mapBorder->grid[i+1][xRows+1] == terrainChar->pokeMart || mapBorder->grid[i+1][xRows+1] == terrainChar->pokemonCenter) {
                mapBorder->grid[i][xRows+2] = object;
                gateInfo->southGate = xRows;
            }
        }
    }
    }
    // connect the east gate to the new west gate
    if(direction == 'e'){
        updownRoad(mapBorder, terrainChar, object, gateInfo);
        int yRows = gateInfo->rightGate; // Initialize the row to start from gateInfo->leftGate
        for (int i = 0; i < 80; i++) {
        // Randomly decide if this section of the road will turn up or down
        int turn = rand() % 10;  // 10% chance to turn
        if (turn == 0) {
            randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
            yRows += randomAmount;  // Move the road up or down
            if (yRows < 4) yRows = 4;  // Don't go above the top boundary
            if (yRows > 21) yRows = 21;  // Don't go below the bottom boundary
        }
        // Place the road section
        if (yRows >= 0 && yRows < 23) {
                if (mapBorder->grid[yRows][i] != terrainChar->pokeMart && mapBorder->grid[yRows][i] != terrainChar->pokemonCenter) {
                    mapBorder->grid[yRows][i] = object;
                    gateInfo->rightGate = yRows;
                }
                else {
                    mapBorder->grid[yRows+1][i] = object;
                    gateInfo->rightGate = yRows+1;
                }
            }
        }
    
    }
    // connect the west gate to the new east gate
    if(direction == 'w'){
        updownRoad(mapBorder, terrainChar, object, gateInfo);
        int yRows = gateInfo->leftGate; // Initialize the row to start from gateInfo->rightGate
        for (int i = 79; i >= 0; i--) {  // Counting from the right side of the map to the left
            int turn = rand() % 10;  // 10% chance to turn
            if (turn == 0) {
                randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1
                yRows += randomAmount;
                if (yRows < 4) yRows = 4;  // Top boundary
                if (yRows > 21) yRows = 21;  // Bottom boundary
            }

            // Place the road section
            if (yRows >= 4 && yRows <= 21) {
                if(mapBorder->grid[yRows][i] != terrainChar->pokeMart && mapBorder->grid[yRows][i] != terrainChar->pokemonCenter){
                    mapBorder->grid[yRows][i] = object;
                    gateInfo->leftGate = yRows;
                } else if (mapBorder->grid[yRows+1][i] == terrainChar->pokeMart || mapBorder->grid[yRows+1][i] == terrainChar->pokemonCenter) {
                    mapBorder->grid[yRows+1][i] = object;
                    gateInfo->leftGate = yRows + 1;
                }
            }
        }
    }
    if(direction == 'f'){
        updownRoad(mapBorder, terrainChar, object, gateInfo);
        leftrightRoad(mapBorder, terrainChar, object, gateInfo);
    }
}
/* The tall grass is to be placed randomly on the map and there need to be two patches of the tall grass
I intend to separate the map into two parts and place the box1 tall grass in the first box and the second box2 in the second box
I intend to use the randomizer to randomize the size of the tall grass and the location of the tall grass
*/
void tallGrass(struct map *mapBorder, struct characters *terrainChar, char object) {

    int x = rand() % 38 + 1;  // Random column between 1 and 38
    int y = rand() % 23 + 1;  // Random row between 1 and 23
    
    for (int i = 0; i < 400; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 38) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 0) x--;
    }
    // Create right patch
    x = rand() % 38 + 41;  // Random column between 41 and 78
    y = rand() % 23 + 1;   // Random row between 1 and 23
    
    for (int i = 0; i < 400; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 78) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 41) x--;
    }

}


/* The boulders are to be placed randomly on the map and the mountains will be placed randomly on the map but not in a square shape
*/
void mountainAndBoulder(struct map *mapBorder, struct characters *terrainChar, char object) {
    int x = 0, y = 0;
    int boulders = (rand() % 10) + 10;  // Random number of boulders between 10 and 19
    
    // Randomly place boulders
    while (boulders >= 0) {
        x = (rand() % 79) + 1;
        y = (rand() % 20) + 4;
        
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
            boulders--;
        }
    }

    // Randomly place mountains
    int mountain_steps = 200;  // Number of steps in the mountain range

    x = (rand() % 79) + 1;  // Starting x-coordinate
    y = (rand() % 20) + 4;  // Starting y-coordinate

    // Randomly select a border (0=top, 1=right, 2=bottom, 3=left)
    int border = rand() % 4;

    // Initialize starting coordinates based on the selected border
    if (border == 0) {
        x = (rand() % 79) + 1; // Random x between 1 and 79
        y = 0; // Top border
    }
    else if (border == 1) {
        x = 79; // Right border
        y = (rand() % 20) + 4; // Random y between 4 and 23
    }
    else if (border == 2) {
        x = (rand() % 79) + 1; // Random x between 1 and 79
        y = 23; // Bottom border
    }
    else {
        x = 0; // Left border
        y = (rand() % 20) + 4; // Random y between 4 and 23
    }

    for (int i = 0; i < mountain_steps; ++i) {
        if ((mapBorder->grid[y][x] != (terrainChar->pokeMart) || mapBorder->grid[y][x] != (terrainChar->pokemonCenter) || mapBorder->grid[y][x] != (terrainChar->roads)) && (mapBorder->grid[y][x] == terrainChar->clearing)) {
            mapBorder->grid[y][x] = object;
        }

        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 79) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 0) x--;
    }
}

/* The trees are to be placed randomly on the map and there need to be two patches of the trees
*/
void trees(struct map *mapBorder, struct characters *terrainChar, char object){
    // Create left patch
    int x = rand() % 38 + 1;  // Random column between 1 and 38
    int y = rand() % 23 + 1;  // Random row between 1 and 23
    
    for (int i = 0; i < 200; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 38) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 0) x--;
    }
    // Create right patch
    x = rand() % 38 + 41;  // Random column between 41 and 78
    y = rand() % 23 + 1;   // Random row between 1 and 23
    
    for (int i = 0; i < 200; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 78) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 41) x--;
    }



}

void randomize(struct map *mapBorder, struct characters *terrainChar){
    tallGrass(mapBorder, terrainChar, terrainChar->grass);
    trees(mapBorder, terrainChar, terrainChar->tree);
    mountainAndBoulder(mapBorder, terrainChar, terrainChar->boulders);
    objectPlacing(mapBorder, terrainChar, terrainChar->pokeMart, 2);
    objectPlacing(mapBorder, terrainChar, terrainChar->pokemonCenter, 2);
    gateCoordinates gateInfo = {0};// initilize the gate struct to zero
    leftrightRoad(mapBorder, terrainChar, terrainChar->roads, &gateInfo);
    updownRoad(mapBorder, terrainChar, terrainChar->roads, &gateInfo);
}

void mapOutput(struct map *mapBorder){
    int rows, columns; // the rows and columns of the map
    for(rows = 0; rows < 24; rows++){
        for(columns = 0; columns < 80; columns++){
            printf("%c", mapBorder->grid[rows][columns]);
        }
        printf("\n");
    }

}


int main(int argc, char* argv[]){

struct characters terrainChar = defaultChar; // initilize the characters in the Character struct

struct map ***mapGrid = malloc(401 * sizeof(struct map**));


srand(time(NULL));// randomize the seed


    printf("generating terrain...\n");
    

for(int i = 0; i < 401; i++){
    mapGrid[i] = malloc(401 * sizeof(struct map*));
    for(int j = 0; j < 401; j++){
        mapGrid[i][j] = NULL;
    }
}
    
    
    int currentX = 200, currentY = 200; // Starting position of the map
    int startpointX = 0, startpointY = 0; // Starting display position of the map
// Create the center map at (200, 200)
    mapGrid[200][200] = malloc(sizeof(struct map));
    map_border(mapGrid[200][200]); // Create the border for the center map
    randomize(mapGrid[200][200], &terrainChar); // Randomize the terrain for the center map
   
    // leftrightRoad(mapGrid[200][200], &terrainChar,terrainChar.roads,&gateInfo);
    // updownRoad(mapGrid[200][200], &terrainChar,terrainChar.roads,&gateInfo);
    mapOutput(mapGrid[200][200]);
    

    
    char command; // input of the player
    
    while (1) {
        printf("Enter direction (n/s/e/w) or q to quit: ");
        scanf(" %c", &command);  // The space before %c eats any leftover \n characters
        if(currentX >= 0 && currentX < 401 && currentY >= 0 && currentY < 401){ // bounds checking for the map
        if(command == 'n'){
            currentY--;
            startpointY--;
             if(currentX >= 400 || currentX < 0 || currentY >= 400 || currentY < 0){ // bounds checking for the map
                    printf("You have reached the edge of the world. You can't go any further\n");
                    printf("Try again\n");
                    // the value will not change if the player tries to go beyond the map
                    if(currentX >= 400) currentX = 399;
                    if(currentY >= 400) currentY = 399;
                    if(currentX < 0) currentX = 0;
                    if(currentY < 0) currentY = 0;
                    mapOutput(mapGrid[currentX][currentY]);
                    continue;
                }
            if(mapGrid[currentX][currentY] == NULL){
                mapGrid[currentX][currentY] = malloc(sizeof(struct map));
                map_border(mapGrid[currentX][currentY]);
                randomize(mapGrid[currentX][currentY], &terrainChar);
                mapOutput(mapGrid[currentX][currentY]);
            }else{
                mapOutput(mapGrid[currentX][currentY]);
            }
            // connectGates(mapGrid[currentX][currentY], &terrainChar, terrainChar.roads, &gateInfo, command); // connect the gates
        }
        if(command == 's'){
            currentY++;
            startpointY++;
                 if(currentX >= 400 || currentX < 0 || currentY >= 400 || currentY < 0){ // bounds checking for the map
                    printf("You have reached the edge of the world. You can't go any further\n");
                    printf("Try again\n");
                    // the value will not change if the player tries to go beyond the map
                    if(currentX >= 400) currentX = 399;
                    if(currentY >= 400) currentY = 399;
                    if(currentX < 0) currentX = 0;
                    if(currentY < 0) currentY = 0;
                    mapOutput(mapGrid[currentX][currentY]);
                    continue;
                }
            if(mapGrid[currentX][currentY] == NULL){
                mapGrid[currentX][currentY] = malloc(sizeof(struct map));
                map_border(mapGrid[currentX][currentY]);
                randomize(mapGrid[currentX][currentY], &terrainChar);
                mapOutput(mapGrid[currentX][currentY]);
            }else{
                mapOutput(mapGrid[currentX][currentY]);
            }
            // connectGates(mapGrid[currentX][currentY], &terrainChar, terrainChar.roads, &gateInfo, command); // connect the gates
        }
        if(command == 'e'){
            currentX++;
            startpointX++;
             if(currentX >= 400 || currentX < 0 || currentY >= 400 || currentY < 0){ // bounds checking for the map
                    printf("You have reached the edge of the world. You can't go any further\n");
                    printf("Try again\n");
                    // the value will not change if the player tries to go beyond the map
                    if(currentX >= 400) currentX = 399;
                    if(currentY >= 400) currentY = 399;
                    if(currentX < 0) currentX = 0;
                    if(currentY < 0) currentY = 0;
                    mapOutput(mapGrid[currentX][currentY]);
                    continue;
                }
            if(mapGrid[currentX][currentY] == NULL){
                mapGrid[currentX][currentY] = malloc(sizeof(struct map));
                map_border(mapGrid[currentX][currentY]);
                randomize(mapGrid[currentX][currentY], &terrainChar);
                mapOutput(mapGrid[currentX][currentY]);
            }else{
                mapOutput(mapGrid[currentX][currentY]);
            }
            // connectGates(mapGrid[currentX][currentY], &terrainChar, terrainChar.roads, &gateInfo, command); // connect the gates
        }
        if(command == 'w'){
            currentX--;
            startpointX--;
             if(currentX >= 400 || currentX < 0 || currentY >= 400 || currentY < 0){ // bounds checking for the map
                    printf("You have reached the edge of the world. You can't go any further\n");
                    printf("Try again\n");
                    // the value will not change if the player tries to go beyond the map
                    if(currentX >= 400) currentX = 399;
                    if(currentY >= 400) currentY = 399;
                    if(currentX < 0) currentX = 0;
                    if(currentY < 0) currentY = 0;
                    mapOutput(mapGrid[currentX][currentY]);
                    continue;
                }
            if(mapGrid[currentX][currentY] == NULL){
                mapGrid[currentX][currentY] = malloc(sizeof(struct map));
                map_border(mapGrid[currentX][currentY]);
                randomize(mapGrid[currentX][currentY], &terrainChar);
                mapOutput(mapGrid[currentX][currentY]);
            }else{
                mapOutput(mapGrid[currentX][currentY]);
            }
            // connectGates(mapGrid[currentX][currentY], &terrainChar, terrainChar.roads, &gateInfo, command); // connect the gates
        }
        if(command == 'f'){
            printf("Enter x and y coordinates: ");
            scanf("%d %d", &startpointX, &startpointY);

            currentX = 200 + startpointX; // the starting point of the map is to be 200 + the input position of the map
            currentY = 200 + startpointY; // the starting point of the map is to be 200 + the input position of the map
             if(currentX >= 400 || currentX < 0 || currentY >= 400 || currentY < 0){ // bounds checking for the map
                    printf("You have reached the edge of the world. You can't go any further\n");
                    printf("Try again\n");
                    // the value will not change if the player tries to go beyond the map
                    if(currentX >= 400) currentX = 399;
                    if(currentY >= 400) currentY = 399;
                    if(currentX < 0) currentX = 0;
                    if(currentY < 0) currentY = 0;
                    mapOutput(mapGrid[currentX][currentY]);
                    continue;
                }
            if(mapGrid[currentX][currentY] == NULL){
                mapGrid[currentX][currentY] = malloc(sizeof(struct map));
                map_border(mapGrid[currentX][currentY]);
                randomize(mapGrid[currentX][currentY], &terrainChar);
                mapOutput(mapGrid[currentX][currentY]);
            }else{
                mapOutput(mapGrid[currentX][currentY]);
            }
        }
        
            if (command == 'q') {
                for (int i = 0; i < 401; i++) {
                    for (int j = 0; j < 401; j++) {
                        if (mapGrid[i][j] != NULL) {
                            free(mapGrid[i][j]); // Free the memory for each map
                            mapGrid[i][j] = NULL; // Set the pointer to NULL
                        }
                    }
                    free(mapGrid[i]); // Free the memory for each row of maps
                }
                free(mapGrid); // Free the memory for the array of maps
                break;
            }
        
        
        if(command != 'n' && command != 's' && command != 'e' && command != 'w' && command != 'f'){ // invalid command
            printf("Invalid command. try n,s, e,w,f\n");
            continue;
        }
        

        // move(&currentX, &currentY, command, mapGrid);
        printf("Current position is (%d, %d)\n", startpointX, startpointY);
    }
    
    }

return 0;
}