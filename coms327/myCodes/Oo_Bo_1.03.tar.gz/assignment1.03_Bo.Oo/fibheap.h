#ifndef HEAP_H
# define HEAP_H

# ifdef __cplusplus
extern "C" {
# endif

// Operations on a Fibonacci heap in C

#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


typedef struct {
int x;
int y;
}playerPosition;

typedef struct NODE{
int key;
int degree;
struct NODE *left_sibling;
struct NODE *right_sibling;
struct NODE *parent;
struct NODE *child;
bool mark;
bool visited;
playerPosition pos;
}NODE;

typedef struct fib_heap{
int n;
NODE *min;
}fib_heap;


fib_heap *make_fib_heap(); //inti the fib
void insertion(fib_heap *h, NODE *new, int data); //insert the fib
void consolidate(fib_heap *h);
void link(fib_heap *h, NODE *y, NODE *x);
void decreaseKey(fib_heap *h, NODE *x, int data);
void cut(fib_heap *h, NODE *nodeToDecrease, NODE *parentNode);
void cascadingCut(fib_heap *h, NODE *parentNode);
void deleteNode(fib_heap *h, int decKey);
void *find_node(fib_heap *h, NODE *n, int key, int new_key);
NODE *extract_min(fib_heap *h);
NODE *findMinNode(fib_heap *h);




# ifdef __cplusplus
}
# endif

#endif
