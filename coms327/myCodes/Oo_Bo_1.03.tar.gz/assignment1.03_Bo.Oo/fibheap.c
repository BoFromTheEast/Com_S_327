#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "fibheap.h"

fib_heap *make_fib_heap(){
fib_heap *h = (fib_heap *)malloc(sizeof(fib_heap));
h->n = 0;
h->min = NULL;
return h;
}

void insertion(fib_heap *h, NODE *new, int data){
// new = (NODE *)malloc(sizeof(NODE));

new->key = data;
new->degree = 0;
new->mark = false;
new->parent = NULL;
new->child = NULL;
new->visited = false;
new->left_sibling = new;
new->right_sibling = new;

if(h->min == NULL){
  h->min = new;
}else {
    h->min->left_sibling->right_sibling = new;
    new->right_sibling = h->min;
    new->left_sibling = h->min->left_sibling;
    h->min->left_sibling = new;
    if (new->key < h->min->key) {
      h->min = new;
    }
  }
  (h->n)++;

}

fib_heap *heapUnion(fib_heap *heap1, fib_heap *heap2){
fib_heap *newheap = make_fib_heap();
if(!heap2->min){
  return heap2;
}else if(!heap2->min){
    return heap1;
}

newheap->min = heap1->min;

NODE *temp1,*temp2;
temp1 = newheap->min->right_sibling;
temp2 = newheap->min->left_sibling;

newheap->min->right_sibling = heap2->min->left_sibling;
newheap->min->left_sibling = heap2->min;
heap2->min->left_sibling = newheap->min;
temp2->right_sibling = temp1;

  if (heap2->min->key < heap1->min->key) {
        newheap->min = heap2->min;
        newheap->n = heap2->n;
    } else {
        newheap->n = heap1->n + heap2->n;
    }
    
    if(newheap->min == NULL){
      printf("heap might be empty");
    }
    return newheap;
}

int calcMaxDegree(int n){
  int count = 0;
  while(n >0){
    n = n/2;
    count++;
  }
  return count;
}

void consolidate(fib_heap *h){
int degree, i, d;
degree = calcMaxDegree(h->n);
NODE *A[degree], *x, *y;
for(i = 0; i <= degree; i++){
  A[i] = NULL;
}
x = h->min;
do {
  d = x->degree; 
  while (A[d] != NULL) {
      y = A[d];
      if (x->key > y->key) {
        NODE *exchange_help;
        exchange_help = x;
        x = y;
        y = exchange_help;
      }
      if (y == h->min)
        h->min = x;
      link(h, y, x);
      if (y->right_sibling == x)
        h->min = x;
      A[d] = NULL;
      d++;
    }
    A[d] = x;
    x = x->right_sibling;
  } while (x != h->min);

  h->min = NULL;
  for (i = 0; i < degree; i++) {
    if (A[i] != NULL) {
      A[i]->left_sibling = A[i];
      A[i]->right_sibling = A[i];
      if (h->min == NULL) {
        h->min = A[i];
      } else {
        h->min->left_sibling->right_sibling = A[i];
        A[i]->right_sibling = h->min;
        A[i]->left_sibling = h->min->left_sibling;
        h->min->left_sibling = A[i];
        if (A[i]->key < h->min->key) {
          h->min = A[i];
        }
      }
      if (h->min == NULL) {
        h->min = A[i];
      } else if (A[i]->key < h->min->key) {
        h->min = A[i];
      }
    }
}
}

void link(fib_heap *h, NODE *y, NODE *x){
y->right_sibling->left_sibling = y->left_sibling;
  y->left_sibling->right_sibling = y->right_sibling;

  if (x->right_sibling == x)
    h->min = x;

  y->left_sibling = y;
  y->right_sibling = y;
  y->parent = x;

  if (x->child == NULL) {
    x->child = y;
  }
  y->right_sibling = x->child;
  y->left_sibling = x->child->left_sibling;
  x->child->left_sibling->right_sibling = y;
  x->child->left_sibling = y;
  if ((y->key) < (x->child->key))
    x->child = y;

  (x->degree)++;
}

void decreaseKey(fib_heap *h, NODE *x, int data){
NODE *parentNode;
  if (h == NULL) {
    printf("\nFibonacci heap not created ");
    return;
  }
  if (x == NULL) {
    printf("Node is not in the heap");
  }

  else {
    if (x->key < data) {
      printf("\n Invalid new key for decrease key operation \n ");
    } else {
      x->key = data;
      parentNode = x->parent;
      if ((parentNode != NULL) && (x->key < parentNode->key)) {
        printf("\n cut called");
        cut(h, x, parentNode);
        printf("\n cascading cut called");
        cascadingCut(h, parentNode);
      }
      if (x->key < h->min->key) {
        h->min = x;
      }
    }
  }
}
void cut(fib_heap *h, NODE *nodeToDecrease, NODE *parentNode){
// NODE *temp_parent_check;

  if (nodeToDecrease == nodeToDecrease->right_sibling)
    parentNode->child = NULL;

  nodeToDecrease->left_sibling->right_sibling = nodeToDecrease->right_sibling;
  nodeToDecrease->right_sibling->left_sibling = nodeToDecrease->left_sibling;
  if (nodeToDecrease == parentNode->child)
    parentNode->child = nodeToDecrease->right_sibling;
  (parentNode->degree)--;

  nodeToDecrease->left_sibling = nodeToDecrease;
  nodeToDecrease->right_sibling = nodeToDecrease;
  h->min->left_sibling->right_sibling = nodeToDecrease;
  nodeToDecrease->right_sibling = h->min;
  nodeToDecrease->left_sibling = h->min->left_sibling;
  h->min->left_sibling = nodeToDecrease;

  nodeToDecrease->parent = NULL;
  nodeToDecrease->mark = false;
}
void cascadingCut(fib_heap *h, NODE *parentNode){
NODE *aux = parentNode->parent;
  if (aux != NULL) {
    if (parentNode->mark == false) {
      parentNode->mark = true;
    } else {
      cut(h, parentNode, aux);
      cascadingCut(h, aux);
    }
  }
}

void *find_node(fib_heap *h, NODE *n, int key, int new_key){
    if (n == NULL) return NULL;

    NODE *current = n;
    do {
        if (current->key == key) {
            decreaseKey(h, current, new_key);
            return current;
        }
        // Search in the child tree of the current node
        NODE *childResult = find_node(h, current->child, key, new_key);
        if (childResult) return childResult;

        // Move to the next node
        current = current->right_sibling;
    } while (current != n);

    return NULL;
}

void deleteNode(fib_heap *h, int decreaseKey){
  NODE *p = NULL;
  find_node(h, h->min, decreaseKey, -5000);
  p = extract_min(h);
  if (p != NULL)
    printf("\n Node deleted");
  else
    printf("\n Node not deleted:some error");
}

NODE *extract_min(fib_heap *h){ //

if (h->min == NULL)
    printf("\n The heap is empty, this sucks\n");
  else {
    NODE *temp = h->min;
    NODE *pntr;
    pntr = temp;
    NODE *x = NULL;
    if (temp->child != NULL) {
      x = temp->child;
      do {
        pntr = x->right_sibling;
        (h->min->left_sibling)->right_sibling = x;
        x->right_sibling = h->min;
        x->left_sibling = h->min->left_sibling;
        h->min->left_sibling = x;
        if (x->key < h->min->key)
          h->min = x;
        x->parent = NULL;
        x = pntr;
      } while (pntr != temp->child);
    }

    (temp->left_sibling)->right_sibling = temp->right_sibling;
    (temp->right_sibling)->left_sibling = temp->left_sibling;
    h->min = temp->right_sibling;

    if (temp == temp->right_sibling && temp->child == NULL)
      h->min = NULL;
    else {
      h->min = temp->right_sibling;
      consolidate(h);
    }
    h->n = h->n - 1;
    return temp;
  }
  return h->min;

  
}

NODE *findMinNode(fib_heap *h){
if (h == NULL) {
    printf(" \n Fibonacci heap not yet created \n");
    return NULL;
  } else
    return h->min;
}

void print_heap(NODE *n) {
  NODE *x;
  for (x = n;; x = x->right_sibling) {
    if (x->child == NULL) {
      printf("node with no child (%d) \n", x->key);
    } else {
      printf("NODE(%d) with child (%d)\n", x->key, x->child->key);
      print_heap(x->child);
    }
    if (x->right_sibling == n) {
      break;
    }
  }
}


// bool isNodeInHeap(fib_heap *h, playerPosition pos) {
//     // Assuming the position or something derived from it is used as the key in your heap
//     int key = computeKeyFromPosition(pos);  // you'll need to implement this function if not already done
//     NODE *result = find_node(h, NULL, key, -1);  // assuming -1 indicates that we don't want to change the key
//     return (result != NULL);  // If the result is not NULL, it means the node is in the heap
// }



// int main(int argc, char **argv) {
//   NODE *new_node, *min_node, *extracted_min, *nodeToDecrease, *find_use;
//   fib_heap *heap, *h1;
//   int operation_no, data, nodeToDelete, ele, i, no_of_nodes;
//   heap = (fib_heap *)malloc(sizeof(fib_heap));
//   heap = NULL;
//   while (1) {
//     printf(" \n Operations \n 1. Create Fibonacci heap \n 2. Insert nodes into fibonacci heap \n 3. Find min \n 4. Union \n 5. Extract min \n 6. Decrease key \n 7.Delete node \n 8. print heap \n 9. exit \n enter operation_no = ");
//     scanf("%d", &operation_no);

//     switch (operation_no) {
//       case 1:
//         heap = make_fib_heap();
//         break;

//       case 2:
//         if (heap == NULL) {
//           heap = make_fib_heap();
//         }
//         printf(" enter number of nodes to be insert = ");
//         scanf("%d", &no_of_nodes);
//         for (i = 1; i <= no_of_nodes; i++) {
//           printf("\n node %d and its key value = ", i);
//           scanf("%d", &ele);
//           insertion(heap, new_node, ele);
//         }
//         break;

//       case 3:
//         min_node = findMinNode(heap);
//         if (min_node == NULL)
//           printf("No minimum value");
//         else
//           printf("\n min value = %d", min_node->key);
//         break;

//       case 4:
//         if (heap == NULL) {
//           printf("\n no FIbonacci heap created \n ");
//           break;
//         }
//         h1 = insertion_procedure();
//         heap = unionheap(heap, h1);
//         printf("Unified heap:\n");
//         print_heap(heap->min);
//         break;

//       case 5:
//         if (heap == NULL)
//           printf("Empty Fibonacci heap");
//         else {
//           extracted_min = extract_min(heap);
//           printf("\n min value = %d", extracted_min->key);
//           printf("\n Updated heap: \n");
//           print_heap(heap->min);
//         }
//         break;

//       case 6:
//         if (heap == NULL)
//           printf("Fibonacci heap is empty");
//         else {
//           printf(" \n node to be decreased = ");
//           scanf("%d", &nodeToDelete);
//           printf(" \n enter the new key = ");
//           scanf("%d", &data);
//           find_use = heap->min;
//           find_node(heap, find_use, nodeToDelete, data);
//           printf("\n Key decreased- Corresponding heap:\n");
//           print_heap(heap->min);
//         }
//         break;
//       case 7:
//         if (heap == NULL)
//           printf("Fibonacci heap is empty");
//         else {
//           printf(" \n Enter node key to be deleted = ");
//           scanf("%d", &nodeToDelete);
//           deleteNode(heap, nodeToDelete);
//           printf("\n Node Deleted- Corresponding heap:\n");
//           print_heap(heap->min);
//           break;
//         }
//       case 8:
//         print_heap(heap->min);
//         break;

//       case 9:
//         free(new_node);
//         free(heap);
//         exit(0);

//       default:
//         printf("Invalid choice ");
//     }
//   }
// }