For this assignment, I had a hard time trying to implement the dijkstra algorithm. Couldn't get the cost of the travel from the npc to the player.

