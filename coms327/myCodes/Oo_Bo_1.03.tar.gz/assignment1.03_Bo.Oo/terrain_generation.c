#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include "fibheap.h"


#define WIDTH 80
#define HEIGHT 24
#define MESSAGEHEIGHT 3
#define INF INT_MAX
#define PLAYER_CHAR '@'
#define HIKER_CHAR 'H'
#define RIVAL_CHAR 'R'

typedef struct{
    int x,y;
}pos;

typedef struct {
    int x;
    int y;
} npcPosition;

/*
The dimension is to be 80 x 24 but the 3 of the 24 is to be used for game message while the 24 -3 = 21 is the actual length for the map;
*/
typedef struct map{
    char grid[HEIGHT][WIDTH]; // 2d array of the map
}map;

/* World Map
*/
typedef struct{
    struct map *worldMap[401][401];
    int leftGate;       // x-coordinate of the left gate
    int rightGate;      // x-coordinate of the right gate
    int northGate;      // y-coordinate of the north gate
    int southGate;      // y-coordinate of the south gate
}worldMap;




/* This is to declare the characters variables
*/
struct characters{
    char tree, grass, clearing,roads, pokemonCenter, pokeMart,boulders;
};

/* This is to initilize the characters in the Character struct
*/
struct characters defaultChar = {
    .tree = '^',
    .boulders = '%',
    .clearing = '.',
    .roads = '#',
    .pokeMart = 'M',
    .pokemonCenter = 'C',
    .grass = ':'
};

typedef enum{ // the type of the terrain
    Bldr,
    Tree,
    Path,
    PMart,
    PCntr,
    TGras,
    SGras,
    Mtn,
    Forest,
    Water,
    Gate,
    TERRAIN_COUNT  //a trick to get the number of terrains
}TerrainType;

typedef enum { // the type of the trainer
    Player,
    Hiker,
    Rival,
    TrainerCount // a trick to get the number of trainers
}TrainerType;

int cost[TrainerCount][TERRAIN_COUNT] = { // cost for the dijkstra's algorithm path
    // Bldr, Tree, Path, PMart, PCntr, TGras, SGras, Mtn, Forest, Water, Gate
    { INF,  INF,  10,   10,    10,    20,    10,    INF,  INF,   INF,  10 },   // Player
    { INF,  INF,  10,   50,    50,    15,    10,    15,   15,    INF,  INF },  // Hiker
    { INF,  INF,  10,   50,    50,    20,    10,    INF,  INF,   INF,  INF }   // Rival
};

TerrainType charToTerrainType(char terrainChar) {
    if (terrainChar == defaultChar.tree) return Tree; 
    if (terrainChar == defaultChar.boulders) return Bldr;
    if (terrainChar == defaultChar.clearing) return SGras; 
    if (terrainChar == defaultChar.roads) return Path;
    if (terrainChar == defaultChar.pokeMart) return PMart;
    if (terrainChar == defaultChar.pokemonCenter) return PCntr;
    if (terrainChar == defaultChar.grass) return TGras;     
    return Gate;  // Default case
}

/*
A map border created as soon as the map is to be generated 
*/
void map_border(struct map *border){
    int rows, columns; // the rows and columns of the map
    /*
    first three rows are supposed to be left empty
    */
    for(rows = 0; rows < 3; rows++){
        for(columns = 0; columns < 80; columns++){
            border->grid[rows][columns] = ' ';
        }
    }
   /*
    This is iterating through the map by going through each row and each column of the rows
    and checking if it is the first row or not to create a border
    and it leaves empty space if not first/last rows and columns
    */
    for(rows = 3; rows < 24; rows++){
        for(columns = 0; columns < 80; columns++){
            if(rows == 3 || rows == 23){
                border->grid[rows][columns] = '%';
            }
            else if(columns == 0 || columns == 79){
                border->grid[rows][columns] = '%';
            
            }
            else{
                border->grid[rows][columns] = '.';
            }
        }
    }
}

/* place the objects in the map
*/
void objectPlacing(struct map *mapBorder, struct characters *terrainChar, char object, int size){
     int x = 0,y = 0;
        do {
        x = (rand() % (78 - size)) + 1;
        y = (rand() % (20 - size)) + 4;
        } while (mapBorder->grid[y][x] != terrainChar->clearing);

    for(int i = 0; i < size; ++i) {
        for(int j = 0; j < size; ++j) {
            mapBorder->grid[y + i][x + j] = object;
        }
    }
}

/* the left and right road
*/
void leftrightRoad(struct map *mapBorder, struct characters *terrainChar, char object, worldMap *mapGrid) {
    int yRows,randomAmount;
    
    /* Got to initialize the variables to 0 to avoid garbage values
        Got to keep VALGRIND happy
    */
    randomAmount = 0;
    yRows = 0;
    yRows = (rand() % 20) + 4;  // Random row starting at 4 to leave the first 3 rows empty
    mapGrid->leftGate = yRows;

    // Horizontal road with occasional turns
for (int i = 0; i < 80; i++) {
    // Randomly decide if this section of the road will turn up or down
    int turn = rand() % 10;  // 10% chance to turn
    if (turn == 0) {
        randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
        yRows += randomAmount;  // Move the road up or down
        if (yRows < 4) yRows = 4;  // Don't go above the top boundary
        if (yRows > 21) yRows = 21;  // Don't go below the bottom boundary
    }
    // Place the road section
    if (yRows >= 0 && yRows < 23) {
            if (mapBorder->grid[yRows][i] != terrainChar->pokeMart && mapBorder->grid[yRows][i] != terrainChar->pokemonCenter) {
                mapBorder->grid[yRows][i] = object;
                mapGrid->rightGate = yRows;
            }
            else {
                mapBorder->grid[yRows+1][i] = object;
                mapGrid->rightGate = yRows+1;
            }
        }
    }
}
/* The up and down road of the map
*/
void updownRoad(struct map *mapBorder, struct characters *terrainChar, char object, worldMap *mapGrid){
    int xRows, randomAmount;
    /* Got to initialize the variables to 0 to avoid garbage values
        Got to keep VALGRIND happy
    */
    randomAmount = 0;
    xRows = 0;
    xRows = (rand() % 78) + 1;  // Random column
    mapGrid->northGate = xRows;

    //Vertical road
    for (int i = 3; i < 24; i++) {  // Starting at 4 to leave the first 3 rows empty
        // Randomly decide if this section of the road will turn up or down
    int turn = rand() % 10;  // 10% chance to turn
    if (turn == 0) {
        randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
        xRows += randomAmount;  // Move the road up or down
        if (xRows < 0) xRows = 0;  // Don't go above the top boundary
        if (xRows > 79) xRows = 79;  // Don't go below the bottom boundary
        }
        // Place the road section
        if (xRows >= 0 && xRows < 79) {
            if(mapBorder->grid[i-1][xRows] != terrainChar->pokeMart || mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
            mapBorder->grid[i][xRows+randomAmount] = object;
            mapGrid->southGate = xRows+randomAmount;
            }else if(mapBorder->grid[i+1][xRows+1] == terrainChar->pokeMart || mapBorder->grid[i+1][xRows+1] == terrainChar->pokemonCenter){ 
                mapBorder->grid[i][xRows+2] = object;
                mapGrid->southGate = xRows;
            }
        }
    }
}

/* Connects the gates
*/
void connectGates(struct map *mapBorder, struct characters *terrainChar, char object, char direction, worldMap *mapGrid){
    int randomAmount = 0;
    // connect the north gate to the new south gate
    if(direction == '\0'){
        leftrightRoad(mapBorder, terrainChar, object, mapGrid);
        updownRoad(mapBorder, terrainChar, object, mapGrid);
    }
    else if(direction == 'n'){
        leftrightRoad(mapBorder, terrainChar, object, mapGrid);
        int xRows = mapGrid->northGate; // Initialize the row to start from mapBorder->upGate

        for (int i = 23; i >= 4; i--) {  // Counting from bottom to top
            int turn = rand() % 10;  // 10% chance to turn

            if (turn == 0 && i < 23) {
                randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1
                xRows += randomAmount;
                if (xRows < 0) xRows = 0;  // Top boundary
                if (xRows > 79) xRows = 79;  // Bottom boundary
            }
            
            // Place the road section
            if (xRows >= 0 && xRows < 80) {
                if(mapBorder->grid[i+1][xRows] != terrainChar->pokeMart || mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
                    mapBorder->grid[i][xRows+randomAmount] = object;
                    mapGrid->southGate = xRows + randomAmount;
                } else if (mapBorder->grid[i-1][xRows-1] == terrainChar->pokeMart || mapBorder->grid[i-1][xRows-1] == terrainChar->pokemonCenter) {
                    mapBorder->grid[i][xRows-2] = object;
                    mapGrid->southGate = xRows;
                }
            }
        }
    }
    // connect the south gate to the new north gate
    else if(direction == 's'){
        int xRows = mapGrid->southGate; // Initialize the row to start from mapBorder->leftGate
        leftrightRoad(mapBorder, terrainChar, object, mapGrid);
        for (int i = 3; i < 24; i++) {
        int turn = rand() % 10;  // 10% chance to turn
        if (turn == 0 && i > 3) {
            randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1
            xRows += randomAmount;
            if (xRows < 0) xRows = 0;  // Top boundary
            if (xRows > 79) xRows = 79;  // Bottom boundary
        }

        if (xRows >= 0 && xRows < 80) {
            if(mapBorder->grid[i-1][xRows] != terrainChar->pokeMart || mapBorder->grid[i][xRows] != terrainChar->pokemonCenter){
                mapBorder->grid[i][xRows+randomAmount] = object;
                mapGrid->southGate = xRows + randomAmount;
            } else if (mapBorder->grid[i+1][xRows+1] == terrainChar->pokeMart || mapBorder->grid[i+1][xRows+1] == terrainChar->pokemonCenter) {
                mapBorder->grid[i][xRows+2] = object;
                mapGrid->southGate = xRows;
            }
        }
    }
    }
    // connect the east gate to the new west gate
    else if(direction == 'e'){
        updownRoad(mapBorder, terrainChar, object, mapGrid);
        int yRows = mapGrid->rightGate; // Initialize the row to start from mapBorder->leftGate
        for (int i = 0; i < 80; i++) {
        // Randomly decide if this section of the road will turn up or down
        int turn = rand() % 10;  // 10% chance to turn
        if (turn == 0 && i > 0) {
            randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1 (to go up or down)
            yRows += randomAmount;  // Move the road up or down
            if (yRows < 4) yRows = 4;  // Don't go above the top boundary
            if (yRows > 21) yRows = 21;  // Don't go below the bottom boundary
        }
        // Place the road section
        if (yRows > 3 && yRows < 23) {
                if (mapBorder->grid[yRows][i] != terrainChar->pokeMart || mapBorder->grid[yRows][i] != terrainChar->pokemonCenter) {
                    mapBorder->grid[yRows][i] = object;
                    mapGrid->rightGate = yRows;
                }
                else {
                    mapBorder->grid[yRows+1][i] = object;
                    mapGrid->rightGate = yRows+1;
                }
            }
        }
    
    }
    // connect the west gate to the new east gate
    else if(direction == 'w'){
        updownRoad(mapBorder, terrainChar, object, mapGrid);
        int yRows = mapGrid->leftGate; // Initialize the row to start from mapBorder->rightGate
        for (int i = 79; i >= 0; i--) {  // Counting from the right side of the map to the left
            int turn = rand() % 10;  // 10% chance to turn
            if (turn == 0 && i < 79) {
                randomAmount = (rand() % 2) * 2 - 1;  // Randomly -1 or 1
                yRows += randomAmount;
                if (yRows < 4) yRows = 4;  // Top boundary
                if (yRows > 21) yRows = 21;  // Bottom boundary
            }

            // Place the road section
            if (yRows > 3 && yRows <= 23) {
                if(mapBorder->grid[yRows][i] != terrainChar->pokeMart || mapBorder->grid[yRows][i] != terrainChar->pokemonCenter){
                    mapBorder->grid[yRows][i] = object;
                    mapGrid->leftGate = yRows;
                } else if (mapBorder->grid[yRows+1][i] == terrainChar->pokeMart || mapBorder->grid[yRows+1][i] == terrainChar->pokemonCenter) {
                    mapBorder->grid[yRows+1][i] = object;
                    mapGrid->leftGate = yRows + 1;
                }
            }
        }
    }
    if(direction == 'f'){
        updownRoad(mapBorder, terrainChar, object, mapGrid);
        leftrightRoad(mapBorder, terrainChar, object, mapGrid);
    }
}
/* The tall grass is to be placed randomly on the map and there need to be two patches of the tall grass
I intend to separate the map into two parts and place the box1 tall grass in the first box and the second box2 in the second box
I intend to use the randomizer to randomize the size of the tall grass and the location of the tall grass
*/
void tallGrass(struct map *mapBorder, struct characters *terrainChar, char object) {

    int x = rand() % 38 + 1;  // Random column between 1 and 38
    int y = rand() % 23 + 1;  // Random row between 1 and 23
    
    for (int i = 0; i < 400; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 38) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 0) x--;
    }
    // Create right patch
    x = rand() % 38 + 41;  // Random column between 41 and 78
    y = rand() % 23 + 1;   // Random row between 1 and 23
    
    for (int i = 0; i < 400; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 78) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 41) x--;
    }

}


/* The boulders are to be placed randomly on the map and the mountains will be placed randomly on the map but not in a square shape
*/
void mountainAndBoulder(struct map *mapBorder, struct characters *terrainChar, char object) {
    int x = 0, y = 0;
    int boulders = (rand() % 10) + 10;  // Random number of boulders between 10 and 19
    
    // Randomly place boulders
    while (boulders >= 0) {
        x = (rand() % 79) + 1;
        y = (rand() % 20) + 4;
        
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
            boulders--;
        }
    }

    // Randomly place mountains
    int mountain_steps = 200;  // Number of steps in the mountain range

    x = (rand() % 79) + 1;  // Starting x-coordinate
    y = (rand() % 20) + 4;  // Starting y-coordinate

    // Randomly select a border (0=top, 1=right, 2=bottom, 3=left)
    int border = rand() % 4;

    // Initialize starting coordinates based on the selected border
    if (border == 0) {
        x = (rand() % 79) + 1; // Random x between 1 and 79
        y = 0; // Top border
    }
    else if (border == 1) {
        x = 79; // Right border
        y = (rand() % 20) + 4; // Random y between 4 and 23
    }
    else if (border == 2) {
        x = (rand() % 79) + 1; // Random x between 1 and 79
        y = 23; // Bottom border
    }
    else {
        x = 0; // Left border
        y = (rand() % 20) + 4; // Random y between 4 and 23
    }

    for (int i = 0; i < mountain_steps; ++i) {
        if ((mapBorder->grid[y][x] != (terrainChar->pokeMart) || mapBorder->grid[y][x] != (terrainChar->pokemonCenter) || mapBorder->grid[y][x] != (terrainChar->roads)) && (mapBorder->grid[y][x] == terrainChar->clearing)) {
            mapBorder->grid[y][x] = object;
        }

        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 79) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 0) x--;
    }
}

/* The trees are to be placed randomly on the map and there need to be two patches of the trees
*/
void trees(struct map *mapBorder, struct characters *terrainChar, char object){
    // Create left patch
    int x = rand() % 38 + 1;  // Random column between 1 and 38
    int y = rand() % 23 + 1;  // Random row between 1 and 23
    
    for (int i = 0; i < 200; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 38) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 0) x--;
    }
    // Create right patch
    x = rand() % 38 + 41;  // Random column between 41 and 78
    y = rand() % 23 + 1;   // Random row between 1 and 23
    
    for (int i = 0; i < 200; ++i) {  // Number of steps
        if (mapBorder->grid[y][x] == terrainChar->clearing) {
            mapBorder->grid[y][x] = object;
        }
        int direction = rand() % 4;  // 0=up, 1=right, 2=down, 3=left
        if (direction == 0 && y > 0) y--;
        if (direction == 1 && x < 78) x++;
        if (direction == 2 && y < 23) y++;
        if (direction == 3 && x > 41) x--;
    }



}

/* randomize the map
*/
void randomize(struct map *mapBorder, struct characters *terrainChar){
    tallGrass(mapBorder, terrainChar, terrainChar->grass);
    trees(mapBorder, terrainChar, terrainChar->tree);
    mountainAndBoulder(mapBorder, terrainChar, terrainChar->boulders);
    objectPlacing(mapBorder, terrainChar, terrainChar->pokeMart, 2);
    objectPlacing(mapBorder, terrainChar, terrainChar->pokemonCenter, 2);
}

/* output the map
*/
void mapOutput(struct map *mapBorder){
    int rows, columns; // the rows and columns of the map
    for(rows = 0; rows < 24; rows++){
        for(columns = 0; columns < 80; columns++){
            printf("%c", mapBorder->grid[rows][columns]);
        }
        printf("\n");
    }

}


/* Dijkstra's algorithm for a 2D grid map */

// Returns true if the position is within the grid and not an obstacle
bool isValidPosition(playerPosition pos, int costMap[HEIGHT][WIDTH]) {
    return pos.x >= 0 && pos.x < HEIGHT && pos.y >= 0 && pos.y < WIDTH && costMap[pos.x][pos.y] != Bldr;
}

// Initialize distance and predecessor arrays
void initializeArrays(int dist[HEIGHT][WIDTH], playerPosition prev[HEIGHT][WIDTH], playerPosition source) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            dist[i][j] = INF; // Set initial distances to infinity
            prev[i][j] = (playerPosition) {-1, -1}; // No predecessor
        }
    }
    dist[source.x][source.y] = 0;
}

void dijkstra(int costMap[HEIGHT][WIDTH], playerPosition source, npcPosition npc, TrainerType npcType) {
    int dist[HEIGHT][WIDTH]; // Distance from source to each cell
    playerPosition prev[HEIGHT][WIDTH]; // Predecessor of each cell
    
    fib_heap *heap = make_fib_heap();// Create a new heap
    NODE* sourceNode = malloc(sizeof(NODE));// Create a new node for the source
    sourceNode->pos = source;// Set the position
    insertion(heap, sourceNode, 0);// Insert the node into the heap
    
    initializeArrays(dist, prev, source);// Initialize the distance and predecessor arrays

    NODE* currentNode = extract_min(heap); // Extract the minimum node from the heap

    while (currentNode != NULL) { // While the heap is not empty
        playerPosition currentPos = currentNode->pos;
        playerPosition neighbors[8] = {
            {currentPos.x + 1, currentPos.y},     // Right
            {currentPos.x - 1, currentPos.y},     // Left
            {currentPos.x, currentPos.y + 1},     // Down
            {currentPos.x, currentPos.y - 1},     // Up
            // Consider removing the following four if diagonals aren't valid moves
            {currentPos.x + 1, currentPos.y + 1}, // Bottom-right
            {currentPos.x - 1, currentPos.y - 1}, // Top-left
            {currentPos.x + 1, currentPos.y - 1}, // Top-right
            {currentPos.x - 1, currentPos.y + 1}  // Bottom-left
        };

        for (int i = 0; i < 8; i++) {
            playerPosition neighbor = neighbors[i];
            if (isValidPosition(neighbor, costMap)) { // Check if the neighbor is valid
                int newDistance = dist[currentPos.x][currentPos.y] + cost[npcType][charToTerrainType(costMap[neighbor.x][neighbor.y])]; // Calculate the new distance
                
                if (newDistance < dist[neighbor.x][neighbor.y]) { // If the new distance is less than the current distance
                    dist[neighbor.x][neighbor.y] = newDistance; // Update the distance
                    prev[neighbor.x][neighbor.y] = currentPos; // Update the predecessor

                    NODE* neighborNode = find_node(heap, heap->min, dist[neighbor.x][neighbor.y], newDistance); // Check if the neighbor is already in the heap
                    if (neighborNode) { // If the neighbor is already in the heap, update its key
                        decreaseKey(heap, neighborNode, newDistance); // Update the key
                    } else {
                        NODE* newNode = malloc(sizeof(NODE)); // Otherwise, create a new node and insert it into the heap
                        newNode->pos = neighbor; // Set the position
                        newNode->key = newDistance; // Set the key
                        insertion(heap, newNode, newDistance); // Insert the node into the heap
                    }
                }
            }
        }
        free(currentNode); // Free the current node
        currentNode = extract_min(heap);// Extract the next node
    }
}



/* Check if the cell is a valid spawn location
*/
bool isValidSpawnLocation(char cell, struct characters *terrainChar) {// Check if the cell is a valid spawn location
    return cell != terrainChar->pokeMart &&
           cell != terrainChar->pokemonCenter &&
           cell != terrainChar->boulders &&
           cell != PLAYER_CHAR;
}

/* The cost map for the NPC
*/
void npcMap(map *mapGrid, TrainerType npcType, playerPosition playerPos, npcPosition npcPos){
int costMap[HEIGHT][WIDTH];

    for(int i = 3; i < HEIGHT; i++){
        for(int j = 0; j < WIDTH; j++){
            char terrain = mapGrid->grid[i][j];
            // Bldr, Tree, Path, PMart, PCntr, TGras, SGras, Mtn, Forest, Water, Gate
            TerrainType terrainType;
            switch (terrain) {
                case '%':
                    terrainType = Bldr;
                    break;
                case '^':
                    terrainType = TGras;
                    break;
                case '.':
                    terrainType = SGras;
                    break;
                case '#':
                    terrainType = Path;
                    break;
                case 'M':
                    terrainType = PMart;
                    break;
                case 'C':
                    terrainType = PCntr;
                    break;
                case ':':
                    terrainType = TGras;
                    break;

                //... add other terrains as needed
                default:
                    terrainType = Gate;  // Example default case, adjust as necessary
                    break;
            }
            costMap[i][j] = cost[npcType][terrainType];
        }
    }
    
    // Print the cost map
    printf("\n");
    for(int i = 3; i < HEIGHT; i++) {
        for(int j = 0; j < WIDTH; j++) {
            if(costMap[i][j] == INF){
                printf(" ");
            }else{
                printf("%d ", costMap[i][j]);
            }   
        }
        printf("\n");
    }
    // Call Dijkstra's algorithm
    dijkstra(costMap, playerPos, npcPos,npcType);
}

/* Spawn the NPC
*/
void spawnNPC(struct map *mapBorder, struct characters *terrainChar, TrainerType typeofNPC, npcPosition npcPos, playerPosition playerPosition){
    int x, y;
    TrainerType npcType;
    
    //for npc
        if (typeofNPC == 'H') {
            npcType = Hiker;
        } else if (typeofNPC == 'R') {
            npcType = Rival;
        }

    while (true) {
        // Generate random x and y within the given bounds
        x = 3 + rand() % (23 - 3);
        y = 1 + rand() % (79 - 1);

        if (isValidSpawnLocation(mapBorder->grid[x][y], terrainChar)) {
            mapBorder->grid[x][y] = typeofNPC;
            npcPos.x = x;
            npcPos.y = y;
            npcMap(mapBorder, npcType, playerPosition, npcPos);
            break;  // Once it found a suitable location and placed the NPC, break out of the loop
        }
    }
    printf("\nPlayer spawned at (%d, %d)\n", playerPosition.x, playerPosition.y);
    printf("NPC Position: %d %d\n",npcPos.x, npcPos.y);
}

/* Spawn player
*/
void spawnPlayer(struct map *mapBorder, struct characters *terrainChar, playerPosition pos, npcPosition npcPos){
//for player
    bool playerPlaced = 0;
    int roadCount = 0;
    for (int i = 3; i < 23; i++) {
        for (int j = 1; j < 79; j++) {
            if (mapBorder->grid[i][j] == terrainChar->roads) {
                roadCount++;
            }
        }
    }
    // If there are no roads, we can't spawn the player on one.
    if (roadCount == 0) {
        fprintf(stderr, "No roads on the map to spawn the player!\n");
        return;
    }
    // Choose a random road tile.
    int chosenRoad = rand() % roadCount; // Random number between 0 and roadCount - 1
    int currentRoad = 0; // The current road we are on
    for (int i = 3; i < 23 && playerPlaced != 1; i++) {
        for (int j = 1; j < 79; j++) {
            if (mapBorder->grid[i][j] == terrainChar->roads) { // If the tile is a road
                if (currentRoad == chosenRoad) { // If this is the randomly chosen road
                    mapBorder->grid[i][j] = PLAYER_CHAR; // Place the player
                    pos.x = i; // Set the player's position
                    pos.y = j; // Set the player's position
                    playerPlaced = 1; // Set the playerPlaced flag to true
                    spawnNPC(mapBorder, terrainChar, RIVAL_CHAR,npcPos,pos); // Spawn the NPC
                    spawnNPC(mapBorder, terrainChar, HIKER_CHAR,npcPos,pos); // Spawn the NPC
                    break; // Exit the function as the player has been placed.
                }
                currentRoad++; // Increment the current road
            }
        }
    }
}


/* Create the map
*/
void createMap(worldMap *mapGrid, struct characters terrainChar, int currentX, int currentY, char direction) {
    if (mapGrid->worldMap[currentX][currentY] == NULL) {
        mapGrid->worldMap[currentX][currentY] = malloc(sizeof(struct map));
        // Check for successful memory allocation
        if (mapGrid->worldMap[currentX][currentY] == NULL) {
            fprintf(stderr, "Memory allocation failed.\n");
            exit(EXIT_FAILURE); // Exit the program
        }
        map_border(mapGrid->worldMap[currentX][currentY]);
        randomize(mapGrid->worldMap[currentX][currentY], &terrainChar);
        if(direction != '\0'){
            connectGates(mapGrid->worldMap[currentX][currentY], &terrainChar, terrainChar.roads, direction, mapGrid); // connect the gates
        }
        playerPosition pos = {0, 0};
        npcPosition npcPos = {0, 0};

        // spawnNPC(mapGrid->worldMap[currentX][currentY], &terrainChar, RIVAL_CHAR, npcPos);
        spawnPlayer(mapGrid->worldMap[currentX][currentY], &terrainChar, pos, npcPos);
        mapOutput(mapGrid->worldMap[currentX][currentY]);
 
    
    } else {
        mapOutput(mapGrid->worldMap[currentX][currentY]);
    }
    printf("\nCurrent position is (%d, %d)\n", currentX-200, currentY-200);
}


int main(int argc, char* argv[]){

struct characters terrainChar = defaultChar; // initilize the characters in the Character struct
worldMap *mapGrid = malloc(sizeof(worldMap));
if(mapGrid == NULL){
    fprintf(stderr, "Memory allocation failed.\n");
    exit(EXIT_FAILURE); // Exit the program
}

for(int i = 0; i < 401; i++){
    for(int j = 0; j < 401; j++){
        mapGrid->worldMap[i][j] = NULL;
    }
}

srand(time(NULL));// randomize the seed
printf("generating terrain...\n");

    int currentX = 200, currentY = 200; // Starting position of the map
    createMap(mapGrid, terrainChar, 200, 200, 'f');
    
    char direction; // input of the player
    
    while (1) {
    printf("Enter direction (n/s/e/w) or q to quit: ");
    scanf(" %c", &direction);  // The space before %c eats any leftover \n characters
        if(currentX >= 400 || currentX < 0 || currentY >= 400 || currentY < 0){ // bounds checking for the map
                    printf("You have reached the edge of the world. You can't go any further\n");
                    printf("Try again\n");
                    // the value will not change if the player tries to go beyond the map
                    if((currentX >= 400)) currentX = 399;
                    if((currentY >= 400)) currentY = 399;
                    if((currentX < 0 )) currentX = 0;
                    if((currentY < 0 )) currentY = 0;
                    mapOutput(mapGrid->worldMap[currentX][currentY]);
                    continue;
                }
    else if(currentX >= 0 && currentX < 401 && currentY >= 0 && currentY < 401){ // bounds checking for the map
        if(direction == 'n'){
            currentY--;
            createMap(mapGrid, terrainChar, currentX, currentY, direction);
        }
        else if(direction == 's'){
            currentY++;
            createMap(mapGrid, terrainChar, currentX, currentY, direction);
        }
        else if(direction == 'e'){
            currentX++;
            createMap(mapGrid, terrainChar, currentX, currentY, direction);
        }
        else if(direction == 'w'){
            currentX--;
            createMap(mapGrid, terrainChar, currentX, currentY, direction);
        }
        else if(direction == 'f'){
            printf("Enter x and y coordinates: ");
            scanf("%d %d", &currentX, &currentY);

            currentX = 200 + currentX; // the starting point of the map is to be 200 + the input position of the map
            currentY = 200 + currentY; // the starting point of the map is to be 200 + the input position of the map
            createMap(mapGrid, terrainChar, currentX, currentY, direction);
        }
            else if (direction == 'q') {
                for (int i = 0; i < 401; i++) {
                    for (int j = 0; j < 401; j++) {
                        if (mapGrid->worldMap[i][j] != NULL) {
                            free(mapGrid->worldMap[i][j]); // Free the memory for each map
                            mapGrid->worldMap[i][j] = NULL; // Set the pointer to NULL
                        }
                    }
                }
                free(mapGrid); // Free the memory for the array of maps
                break;
            }
        
    }
    if(direction != 'n' && direction != 's' && direction != 'e' && direction != 'w' && direction != 'f'){ // invalid command
            printf("\nInvalid command. try n,s,e,w,f \n");
        }
    }

return 0;
}